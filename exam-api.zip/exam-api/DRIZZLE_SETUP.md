# Exam API - Drizzle ORM設定完了

## 概要

試験システムのDrizzle ORM設定が完了しました。21テーブルのスキーマ定義と、マイグレーション管理の準備が整っています。

## 作成されたファイル

### スキーマファイル

- [`src/db/schema/users.schema.ts`](src/db/schema/users.schema.ts) - ユーザー関連
- [`src/db/schema/categories.schema.ts`](src/db/schema/categories.schema.ts) - カテゴリー関連
- [`src/db/schema/tags.schema.ts`](src/db/schema/tags.schema.ts) - タグ関連
- [`src/db/schema/exams.schema.ts`](src/db/schema/exams.schema.ts) - 試験関連
- [`src/db/schema/questions.schema.ts`](src/db/schema/questions.schema.ts) - 問題関連
- [`src/db/schema/attempts.schema.ts`](src/db/schema/attempts.schema.ts) - 受験関連
- [`src/db/schema/statistics.schema.ts`](src/db/schema/statistics.schema.ts) - 統計関連
- [`src/db/schema/index.ts`](src/db/schema/index.ts) - 全スキーマのエクスポート

### 設定ファイル

- [`drizzle.config.ts`](drizzle.config.ts) - Drizzle Kit設定
- [`src/plugins/04.db.plugin.ts`](src/plugins/04.db.plugin.ts) - DBプラグイン（更新済み）
- [`src/type.d.ts`](src/type.d.ts) - 型定義（更新済み）

## データベーススキーマ

### テーブル一覧（21テーブル）

#### ユーザー管理

- `users` - ユーザー情報

#### カテゴリー管理

- `exam_categories` - 試験カテゴリー
- `exam_category_translations` - カテゴリー翻訳（ja/en/zh）

#### タグ管理

- `exam_tags` - 試験タグ
- `exam_tag_translations` - タグ翻訳（ja/en/zh）
- `exam_tag_relations` - 試験とタグの関連（多対多）

#### 試験管理

- `exams` - 試験情報
- `exam_translations` - 試験翻訳（ja/en/zh）

#### 問題管理

- `questions` - 問題情報
- `question_translations` - 問題翻訳（ja/en/zh）
- `choices` - 選択肢
- `choice_translations` - 選択肢翻訳（ja/en/zh）
- `explanations` - 解説
- `explanation_translations` - 解説翻訳（ja/en/zh）

#### 受験管理

- `exam_attempts` - 受験記録
- `user_answers` - ユーザー解答
- `wrong_questions` - 錯題集
- `bookmarks` - ブックマーク

#### 統計情報

- `user_statistics` - ユーザー統計
- `exam_statistics` - 試験統計
- `question_statistics` - 問題統計

## 使用方法

### 1. 環境変数の設定

`env/.env`ファイルに以下を追加：

```env
DATABASE_URL=postgresql://user:password@localhost:5432/exam_db
```

### 2. マイグレーションファイルの生成

スキーマからマイグレーションファイルを生成：

```bash
npm run db:generate
```

これにより、`src/db/migrations/`ディレクトリにSQLマイグレーションファイルが生成されます。

### 3. マイグレーションの実行

データベースにマイグレーションを適用：

```bash
npm run db:migrate
```

### 4. スキーマのプッシュ（開発環境）

開発環境で直接スキーマをプッシュ（マイグレーションファイルなし）：

```bash
npm run db:push
```

⚠️ **注意**: 本番環境では`db:migrate`を使用してください。

### 5. Drizzle Studioの起動

ブラウザベースのデータベース管理ツール：

```bash
npm run db:studio
```

https://local.drizzle.studio でアクセス可能

### 6. マイグレーションの削除

最後のマイグレーションを削除：

```bash
npm run db:drop
```

## コード例

### 1. ユーザーの作成

```typescript
import { users } from '@/db/schema/index.js';

// ルートハンドラー内
const newUser = await fastify.db
  .insert(users)
  .values({
    cognitoSub: 'cognito-sub-id',
    username: 'testuser',
    email: 'test@example.com',
    preferredLanguage: 'ja',
  })
  .returning();
```

### 2. 試験の取得（リレーション含む）

```typescript
import { eq } from 'drizzle-orm';

import { examTranslations, exams } from '@/db/schema/index.js';

const exam = await fastify.db.query.exams.findFirst({
  where: eq(exams.id, examId),
  with: {
    translations: {
      where: eq(examTranslations.languageCode, 'ja'),
    },
    questions: {
      with: {
        translations: true,
        choices: {
          with: {
            translations: true,
          },
        },
      },
    },
  },
});
```

### 3. 受験履歴の取得

```typescript
import { and, desc, eq } from 'drizzle-orm';

import { examAttempts, examTranslations, exams } from '@/db/schema/index.js';

const attempts = await fastify.db.query.examAttempts.findMany({
  where: and(eq(examAttempts.userId, userId), eq(examAttempts.examId, examId), eq(examAttempts.status, 'completed')),
  orderBy: [desc(examAttempts.attemptNumber)],
  with: {
    exam: {
      with: {
        translations: {
          where: eq(examTranslations.languageCode, 'ja'),
        },
      },
    },
  },
});
```

### 4. トランザクション

```typescript
await fastify.db.transaction(async (tx) => {
  // 試験を作成
  const [exam] = await tx
    .insert(exams)
    .values({
      categoryId: 'category-uuid',
      createdBy: 'user-uuid',
      passingScore: 720,
      totalScore: 1000,
    })
    .returning();

  // 翻訳を追加
  await tx.insert(examTranslations).values([
    {
      examId: exam.id,
      languageCode: 'ja',
      title: 'AWS SAA模擬試験',
      description: '試験説明',
    },
    {
      examId: exam.id,
      languageCode: 'en',
      title: 'AWS SAA Mock Exam',
      description: 'Exam description',
    },
  ]);
});
```

## スキーマの特徴

### 1. 型安全性

- Drizzle ORMの型推論により、完全な型安全性を実現
- `$inferSelect`と`$inferInsert`で自動型生成

### 2. リレーション

- `relations()`で型安全なリレーションクエリ
- ネストされたクエリが可能

### 3. 多言語対応

- 翻訳テーブルで日本語、英語、中国語をサポート
- `languageCode`カラムで言語を識別

### 4. 論理削除

- 主要テーブルに`deletedAt`カラム
- 物理削除せず、履歴を保持

### 5. 外部キー制約

- `onDelete: 'cascade'` - 親レコード削除時に子レコードも削除
- `onDelete: 'set null'` - 親レコード削除時にNULLを設定

## 次のステップ

1. **マイグレーションの実行**: `npm run db:generate && npm run db:migrate`
2. **Zodバリデーションスキーマの実装**: [`plans/zod-schema-design.md`](plans/zod-schema-design.md)を参照
3. **APIエンドポイントの実装**: [`plans/api-design.md`](plans/api-design.md)を参照
4. **認証ミドルウェアの実装**: AWS Cognito JWT検証

## トラブルシューティング

### マイグレーションエラー

```bash
# マイグレーションファイルを削除して再生成
npm run db:drop
npm run db:generate
npm run db:migrate
```

### 型エラー

```bash
# TypeScriptの型チェック
npx tsc --noEmit
```

### データベース接続エラー

`env/.env`ファイルの`DATABASE_URL`を確認してください。

## 参考資料

- [Drizzle ORM公式ドキュメント](https://orm.drizzle.team/)
- [Drizzle Kit公式ドキュメント](https://orm.drizzle.team/kit-docs/overview)
- [データベース設計ドキュメント](plans/database-design.md)
- [API設計ドキュメント](plans/api-design.md)
