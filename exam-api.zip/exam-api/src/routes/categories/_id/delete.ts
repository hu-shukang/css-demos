import { eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';

import { examCategories } from '@/db/schema/index.js';
import { badRequestSchema, notFoundSchema, successSchema } from '@/models/common.model.js';
import { SCHEMA } from '@/utils/const.util.js';

const routes = async (fastify: FastifyInstance) => {
  fastify.withTypeProvider<ZodTypeProvider>().delete(
    '',
    {
      schema: {
        summary: 'カテゴリー削除',
        description: 'カテゴリーを論理削除します',
        tags: [SCHEMA.tags.category.name],
        params: z.object({
          id: SCHEMA.z.category.id,
        }),
        response: {
          200: successSchema,
          400: badRequestSchema,
          404: notFoundSchema,
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params;

      // カテゴリーの存在確認
      const [existingCategory] = await fastify.db
        .select()
        .from(examCategories)
        .where(eq(examCategories.id, id))
        .limit(1);

      if (!existingCategory) {
        return reply.code(404).send({
          error: 'Not Found',
          message: 'カテゴリーが見つかりません',
        });
      }

      // 論理削除
      await fastify.db
        .update(examCategories)
        .set({
          deletedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(examCategories.id, id));

      return {
        success: 'OK' as const,
      };
    },
  );
};

export default routes;
