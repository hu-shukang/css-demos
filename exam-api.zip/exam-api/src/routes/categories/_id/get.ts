import { eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';

import { examCategories } from '@/db/schema/index.js';
import { categoryResponseSchema } from '@/models/category.model.js';
import { badRequestSchema, notFoundSchema } from '@/models/common.model.js';
import { SCHEMA } from '@/utils/const.util.js';

const routes = async (fastify: FastifyInstance) => {
  fastify.withTypeProvider<ZodTypeProvider>().get(
    '',
    {
      schema: {
        summary: 'カテゴリー詳細取得',
        description: 'カテゴリーIDでカテゴリーを取得します',
        tags: [SCHEMA.tags.category.name],
        params: z.object({
          id: SCHEMA.z.category.id,
        }),
        response: {
          200: categoryResponseSchema,
          400: badRequestSchema,
          404: notFoundSchema,
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params;

      // カテゴリーを取得
      const results = await fastify.db.select().from(examCategories).where(eq(examCategories.id, id)).limit(1);

      if (results.length === 0) {
        return reply.code(404).send({
          error: 'Not Found',
          message: 'カテゴリーが見つかりません',
        });
      }

      const category = results[0];

      return {
        id: category.id,
        parentId: category.parentId,
        name: category.name,
        description: category.description,
        sortOrder: category.sortOrder,
        createdAt: category.createdAt.toISOString(),
        updatedAt: category.updatedAt ? category.updatedAt.toISOString() : null,
        deletedAt: category.deletedAt ? category.deletedAt.toISOString() : null,
      };
    },
  );
};

export default routes;
