import { eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';

import { examCategories } from '@/db/schema/index.js';
import { categoryResponseSchema, updateCategoryRequestSchema } from '@/models/category.model.js';
import { badRequestSchema, notFoundSchema } from '@/models/common.model.js';
import { SCHEMA } from '@/utils/const.util.js';

const routes = async (fastify: FastifyInstance) => {
  fastify.withTypeProvider<ZodTypeProvider>().put(
    '',
    {
      schema: {
        summary: 'カテゴリー更新',
        description: 'カテゴリーを更新します',
        tags: [SCHEMA.tags.category.name],
        params: z.object({
          id: SCHEMA.z.category.id,
        }),
        body: updateCategoryRequestSchema,
        response: {
          200: categoryResponseSchema,
          400: badRequestSchema,
          404: notFoundSchema,
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params;
      const { name, description, sortOrder, deletedAt } = request.body;

      // カテゴリーの存在確認
      const [existingCategory] = await fastify.db
        .select()
        .from(examCategories)
        .where(eq(examCategories.id, id))
        .limit(1);

      if (!existingCategory) {
        return reply.code(404).send({
          error: 'Not Found',
          message: 'カテゴリーが見つかりません',
        });
      }

      // カテゴリーを更新
      const categoryUpdate: Record<string, unknown> = {
        updatedAt: new Date(),
      };
      if (name !== undefined) {
        categoryUpdate.name = name;
      }
      if (description !== undefined) {
        categoryUpdate.description = description;
      }
      if (sortOrder !== undefined) {
        categoryUpdate.sortOrder = sortOrder;
      }
      if (deletedAt !== undefined) {
        categoryUpdate.deletedAt = deletedAt ? new Date(deletedAt) : null;
      }

      await fastify.db.update(examCategories).set(categoryUpdate).where(eq(examCategories.id, id));

      // 更新後のデータを取得
      const [updatedCategory] = await fastify.db
        .select()
        .from(examCategories)
        .where(eq(examCategories.id, id))
        .limit(1);

      return {
        id: updatedCategory.id,
        parentId: updatedCategory.parentId,
        name: updatedCategory.name,
        description: updatedCategory.description,
        sortOrder: updatedCategory.sortOrder,
        createdAt: updatedCategory.createdAt.toISOString(),
        updatedAt: updatedCategory.updatedAt ? updatedCategory.updatedAt.toISOString() : null,
        deletedAt: updatedCategory.deletedAt ? updatedCategory.deletedAt.toISOString() : null,
      };
    },
  );
};

export default routes;
