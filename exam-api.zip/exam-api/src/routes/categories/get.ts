import { count, isNull } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';

import { examCategories } from '@/db/schema/index.js';
import { categoryListResponseSchema } from '@/models/category.model.js';
import { badRequestSchema } from '@/models/common.model.js';
import { paginationQuerySchema } from '@/models/common.model.js';
import { SCHEMA } from '@/utils/const.util.js';

const routes = async (fastify: FastifyInstance) => {
  fastify.withTypeProvider<ZodTypeProvider>().get(
    '',
    {
      schema: {
        summary: 'カテゴリー一覧取得',
        description: 'カテゴリーの一覧を取得します',
        tags: [SCHEMA.tags.category.name],
        querystring: paginationQuerySchema,
        response: {
          200: categoryListResponseSchema,
          400: badRequestSchema,
        },
      },
    },
    async (request, _reply) => {
      const { page = 1, limit = 20 } = request.query;
      const offset = (page - 1) * limit;

      // 総件数を取得
      const [{ total }] = await fastify.db
        .select({ total: count() })
        .from(examCategories)
        .where(isNull(examCategories.deletedAt));

      // カテゴリーを取得
      const results = await fastify.db
        .select()
        .from(examCategories)
        .where(isNull(examCategories.deletedAt))
        .limit(limit)
        .offset(offset);

      const totalPages = Math.ceil(total / limit);

      return {
        items: results.map((row) => ({
          id: row.id,
          parentId: row.parentId,
          name: row.name,
          description: row.description,
          sortOrder: row.sortOrder,
          createdAt: row.createdAt.toISOString(),
          updatedAt: row.updatedAt ? row.updatedAt.toISOString() : null,
          deletedAt: row.deletedAt ? row.deletedAt.toISOString() : null,
        })),
        pagination: {
          page,
          limit,
          total,
          totalPages,
        },
      };
    },
  );
};

export default routes;
