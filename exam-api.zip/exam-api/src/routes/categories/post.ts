import { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';

import { examCategories } from '@/db/schema/index.js';
import { categoryResponseSchema, createCategoryRequestSchema } from '@/models/category.model.js';
import { badRequestSchema } from '@/models/common.model.js';
import { SCHEMA } from '@/utils/const.util.js';

const routes = async (fastify: FastifyInstance) => {
  fastify.withTypeProvider<ZodTypeProvider>().post(
    '',
    {
      schema: {
        summary: 'カテゴリー作成',
        description: '新しいカテゴリーを作成します',
        tags: [SCHEMA.tags.category.name],
        body: createCategoryRequestSchema,
        response: {
          201: categoryResponseSchema,
          400: badRequestSchema,
        },
      },
    },
    async (request, reply) => {
      const { parentId, name, description, sortOrder } = request.body;

      // カテゴリーを作成
      const [category] = await fastify.db
        .insert(examCategories)
        .values({
          parentId,
          name,
          description,
          sortOrder,
        })
        .returning();

      // レスポンスを構築
      return reply.code(201).send({
        id: category.id,
        parentId: category.parentId,
        name: category.name,
        description: category.description,
        sortOrder: category.sortOrder,
        createdAt: category.createdAt.toISOString(),
        updatedAt: category.updatedAt ? category.updatedAt.toISOString() : null,
        deletedAt: category.deletedAt ? category.deletedAt.toISOString() : null,
      });
    },
  );
};

export default routes;
