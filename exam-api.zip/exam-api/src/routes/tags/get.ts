import { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';

import { badRequestSchema } from '@/models/common.model.js';
import { paginationQuerySchema } from '@/models/common.model.js';
import { tagListResponseSchema } from '@/models/tag.model.js';
import { getTagList, getTotalCount } from '@/services/tag.service.js';
import { SCHEMA } from '@/utils/const.util.js';

const routes = async (fastify: FastifyInstance) => {
  fastify.withTypeProvider<ZodTypeProvider>().get(
    '',
    {
      schema: {
        summary: 'タグ一覧取得',
        description: 'タグの一覧を取得します',
        tags: [SCHEMA.tags.tag.name],
        querystring: paginationQuerySchema,
        response: {
          200: tagListResponseSchema,
          400: badRequestSchema,
        },
      },
    },
    async (request, _reply) => {
      const { page = 1, limit = 20 } = request.query;
      const offset = (page - 1) * limit;

      // 総件数を取得
      const total = await getTotalCount().with(fastify.db);

      // タグを取得
      const results = await getTagList(limit, offset).with(fastify.db);

      const totalPages = Math.ceil(total / limit);

      return {
        items: results,
        pagination: {
          page,
          limit,
          total,
          totalPages,
        },
      };
    },
  );
};

export default routes;
