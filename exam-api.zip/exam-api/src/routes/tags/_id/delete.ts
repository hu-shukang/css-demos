import { eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';

import { examTags } from '@/db/schema/index.js';
import { badRequestSchema, notFoundSchema, successSchema } from '@/models/common.model.js';
import { SCHEMA } from '@/utils/const.util.js';

const routes = async (fastify: FastifyInstance) => {
  fastify.withTypeProvider<ZodTypeProvider>().delete(
    '',
    {
      schema: {
        summary: 'タグ削除',
        description: 'タグを削除します',
        tags: [SCHEMA.tags.tag.name],
        params: z.object({
          id: SCHEMA.z.tag.id,
        }),
        response: {
          200: successSchema,
          400: badRequestSchema,
          404: notFoundSchema,
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params;

      // タグの存在確認
      const [existingTag] = await fastify.db.select().from(examTags).where(eq(examTags.id, id)).limit(1);

      if (!existingTag) {
        return reply.code(404).send({
          error: 'Not Found',
          message: 'タグが見つかりません',
        });
      }

      // 物理削除（タグテーブルにはdeletedAtフィールドがないため）
      await fastify.db.delete(examTags).where(eq(examTags.id, id));

      return {
        success: 'OK' as const,
      };
    },
  );
};

export default routes;
