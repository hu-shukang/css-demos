import { eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';

import { examTags } from '@/db/schema/index.js';
import { badRequestSchema, notFoundSchema } from '@/models/common.model.js';
import { tagResponseSchema, updateTagRequestSchema } from '@/models/tag.model.js';
import { SCHEMA } from '@/utils/const.util.js';

const routes = async (fastify: FastifyInstance) => {
  fastify.withTypeProvider<ZodTypeProvider>().put(
    '',
    {
      schema: {
        summary: 'タグ更新',
        description: 'タグを更新します',
        tags: [SCHEMA.tags.tag.name],
        params: z.object({
          id: SCHEMA.z.tag.id,
        }),
        body: updateTagRequestSchema,
        response: {
          200: tagResponseSchema,
          400: badRequestSchema,
          404: notFoundSchema,
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params;
      const { name, deletedAt } = request.body;

      // タグの存在確認
      const [existingTag] = await fastify.db.select().from(examTags).where(eq(examTags.id, id)).limit(1);

      if (!existingTag) {
        return reply.code(404).send({
          error: 'Not Found',
          message: 'タグが見つかりません',
        });
      }

      // タグを更新
      const tagUpdate: Record<string, unknown> = {
        updatedAt: new Date(),
      };
      if (name !== undefined) {
        tagUpdate.name = name;
      }

      const [updatedTag] = await fastify.db.update(examTags).set(tagUpdate).where(eq(examTags.id, id)).returning();

      return {
        id: updatedTag.id,
        name: updatedTag.name,
        createdAt: updatedTag.createdAt.toISOString(),
        updatedAt: updatedTag.updatedAt ? updatedTag.updatedAt.toISOString() : null,
        deletedAt: deletedAt ? new Date(deletedAt).toISOString() : null,
      };
    },
  );
};

export default routes;
