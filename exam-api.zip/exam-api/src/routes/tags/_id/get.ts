import { eq } from 'drizzle-orm';
import { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';

import { examTags } from '@/db/schema/index.js';
import { badRequestSchema, notFoundSchema } from '@/models/common.model.js';
import { tagResponseSchema } from '@/models/tag.model.js';
import { SCHEMA } from '@/utils/const.util.js';

const routes = async (fastify: FastifyInstance) => {
  fastify.withTypeProvider<ZodTypeProvider>().get(
    '',
    {
      schema: {
        summary: 'タグ詳細取得',
        description: 'タグIDでタグを取得します',
        tags: [SCHEMA.tags.tag.name],
        params: z.object({
          id: SCHEMA.z.tag.id,
        }),
        response: {
          200: tagResponseSchema,
          400: badRequestSchema,
          404: notFoundSchema,
        },
      },
    },
    async (request, reply) => {
      const { id } = request.params;

      // タグを取得
      const [tag] = await fastify.db.select().from(examTags).where(eq(examTags.id, id)).limit(1);

      if (!tag) {
        return reply.code(404).send({
          error: 'Not Found',
          message: 'タグが見つかりません',
        });
      }

      return {
        id: tag.id,
        name: tag.name,
        createdAt: tag.createdAt.toISOString(),
        updatedAt: tag.updatedAt ? tag.updatedAt.toISOString() : null,
        deletedAt: null,
      };
    },
  );
};

export default routes;
