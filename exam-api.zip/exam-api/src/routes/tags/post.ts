import { FastifyInstance } from 'fastify';
import type { ZodTypeProvider } from 'fastify-type-provider-zod';

import { badRequestSchema } from '@/models/common.model.js';
import { createTagRequestSchema, tagResponseSchema } from '@/models/tag.model.js';
import { createTag } from '@/services/tag.service.js';
import { SCHEMA } from '@/utils/const.util.js';

const routes = async (fastify: FastifyInstance) => {
  fastify.withTypeProvider<ZodTypeProvider>().post(
    '',
    {
      schema: {
        summary: 'タグ作成',
        description: '新しいタグを作成します',
        tags: [SCHEMA.tags.tag.name],
        body: createTagRequestSchema,
        response: {
          201: tagResponseSchema,
          400: badRequestSchema,
        },
      },
    },
    async (request, reply) => {
      const [tag] = await createTag(request.body).with(fastify.db);

      // レスポンスを構築
      return reply.code(201).send(tag);
    },
  );
};

export default routes;
