import { ExtractTablesWithRelations } from 'drizzle-orm';
import { NodePgDatabase, NodePgQueryResultHKT } from 'drizzle-orm/node-postgres';
import { PgTransaction } from 'drizzle-orm/pg-core';
import 'fastify';
import { Pool } from 'pg';

import * as schema from '@/db/schema/index.js';

export type DrizzleDB =
  | (NodePgDatabase<typeof schema> & {
      $client: Pool;
    })
  | PgTransaction<NodePgQueryResultHKT, typeof schema, ExtractTablesWithRelations<typeof schema>>;

declare module 'fastify' {
  interface FastifyInstance {
    db: DrizzleDB;
    config: {
      NODE_ENV: 'test' | 'dev' | 'it' | 'prod';
      PORT: number;
      DATABASE_URL: string;
      LOG_LEVEL: 'trace' | 'debug' | 'info' | 'warn' | 'error' | 'fatal';
      CORS: 'ON' | 'OFF';
      SWAGGER: 'ON' | 'OFF';
    };
  }
}
