import { z } from 'zod';

export const SCHEMA = {
  swagger: {
    routePrefix: '/doc',
  },
  tags: {
    category: {
      name: 'category',
      description: 'カテゴリーAPI',
    },
    tag: {
      name: 'tag',
      description: 'タグAPI',
    },
    exam: {
      name: 'exam',
      description: '試験API',
    },
    question: {
      name: 'question',
      description: '問題API',
    },
    attempt: {
      name: 'attempt',
      description: '受験API',
    },
    wrongQuestion: {
      name: 'wrong-question',
      description: '錯題集API',
    },
    bookmark: {
      name: 'bookmark',
      description: 'ブックマークAPI',
    },
    statistics: {
      name: 'statistics',
      description: '統計API',
    },
  },
  z: {
    // ===================================
    // Common Schemas
    // ===================================
    common: {
      id: z
        .string({ message: 'IDは文字列である必要があります' })
        .uuid({ message: 'IDはUUIDである必要があります' })
        .describe('ID'),
      createdAt: z.date({ message: '作成日時はISO 8601形式の日時である必要があります' }).describe('作成日時'),
      updatedAt: z.date({ message: '更新日時はISO 8601形式の日時である必要があります' }).describe('更新日時'),
      deletedAt: z.date({ message: '削除日時はISO 8601形式の日時である必要があります' }).describe('削除日時'),
      sortOrder: z
        .number({ message: '表示順序は数値である必要があります' })
        .int({ message: '表示順序は整数である必要があります' })
        .min(0, { message: '表示順序は0以上である必要があります' })
        .describe('表示順序'),
      page: z
        .number({ message: 'ページ番号は数値である必要があります' })
        .int({ message: 'ページ番号は整数である必要があります' })
        .min(1, { message: 'ページ番号は1以上である必要があります' })
        .default(1)
        .describe('ページ番号'),
      limit: z
        .number({ message: '件数は数値である必要があります' })
        .int({ message: '件数は整数である必要があります' })
        .min(1, { message: '件数は1以上である必要があります' })
        .max(100, { message: '件数は100以下である必要があります' })
        .default(20)
        .describe('1ページあたりの件数'),
      error: z.string().describe('エラー'),
      message: z.string().describe('メッセージ'),
      path: z.string().describe('パス'),
      success: z.literal('OK').describe('成功'),
    },

    // ===================================
    // User Schemas
    // ===================================
    user: {
      id: z
        .string({ message: 'ユーザーIDは文字列である必要があります' })
        .uuid({ message: 'ユーザーIDはUUIDである必要があります' })
        .describe('ユーザーID'),
      cognitoSub: z
        .string({ message: 'Cognito SubIDは文字列である必要があります' })
        .min(1, { message: 'Cognito SubIDは必須です' })
        .describe('Cognito SubID'),
      username: z
        .string({ message: 'ユーザー名は文字列である必要があります' })
        .min(1, { message: 'ユーザー名は必須です' })
        .max(100, { message: 'ユーザー名は100文字以内である必要があります' })
        .describe('ユーザー名'),
      email: z
        .string({ message: 'メールアドレスは文字列である必要があります' })
        .email({ message: 'メールアドレスはメールアドレスの形式である必要があります' })
        .describe('メールアドレス'),
      preferredLanguage: z
        .enum(['ja', 'en', 'zh'], { message: '優先言語はja、en、zhのいずれかである必要があります' })
        .describe('優先言語'),
    },

    // ===================================
    // Category Schemas
    // ===================================
    category: {
      id: z
        .string({ message: 'カテゴリーIDは文字列である必要があります' })
        .uuid({ message: 'カテゴリーIDはUUIDである必要があります' })
        .describe('カテゴリーID'),
      parentId: z
        .string({ message: '親カテゴリーIDは文字列である必要があります' })
        .uuid({ message: '親カテゴリーIDはUUIDである必要があります' })
        .nullable()
        .describe('親カテゴリーID'),
      name: z
        .string({ message: 'カテゴリー名は文字列である必要があります' })
        .min(1, { message: 'カテゴリー名は必須です' })
        .max(200, { message: 'カテゴリー名は200文字以内である必要があります' })
        .describe('カテゴリー名'),
      description: z
        .string({ message: 'カテゴリー説明は文字列である必要があります' })
        .max(1000, { message: 'カテゴリー説明は1000文字以内である必要があります' })
        .nullable()
        .describe('カテゴリー説明'),
    },

    // ===================================
    // Tag Schemas
    // ===================================
    tag: {
      id: z
        .string({ message: 'タグIDは文字列である必要があります' })
        .uuid({ message: 'タグIDはUUIDである必要があります' })
        .describe('タグID'),
      name: z
        .string({ message: 'タグ名は文字列である必要があります' })
        .min(1, { message: 'タグ名は必須です' })
        .max(100, { message: 'タグ名は100文字以内である必要があります' })
        .describe('タグ名'),
    },

    // ===================================
    // Exam Schemas
    // ===================================
    exam: {
      id: z
        .string({ message: '試験IDは文字列である必要があります' })
        .uuid({ message: '試験IDはUUIDである必要があります' })
        .describe('試験ID'),
      title: z
        .string({ message: '試験タイトルは文字列である必要があります' })
        .min(1, { message: '試験タイトルは必須です' })
        .max(500, { message: '試験タイトルは500文字以内である必要があります' })
        .describe('試験タイトル'),
      description: z
        .string({ message: '試験説明は文字列である必要があります' })
        .max(5000, { message: '試験説明は5000文字以内である必要があります' })
        .nullable()
        .describe('試験説明'),
      instructions: z
        .string({ message: '受験上の注意は文字列である必要があります' })
        .max(5000, { message: '受験上の注意は5000文字以内である必要があります' })
        .nullable()
        .describe('受験上の注意'),
      status: z
        .enum(['draft', 'published', 'archived'], {
          message: 'ステータスはdraft、published、archivedのいずれかである必要があります',
        })
        .describe('ステータス'),
      difficultyLevel: z
        .enum(['beginner', 'intermediate', 'advanced'], {
          message: '難易度はbeginner、intermediate、advancedのいずれかである必要があります',
        })
        .nullable()
        .describe('難易度'),
      passingScore: z
        .number({ message: '合格点は数値である必要があります' })
        .int({ message: '合格点は整数である必要があります' })
        .min(0, { message: '合格点は0以上である必要があります' })
        .describe('合格点'),
      totalScore: z
        .number({ message: '満点は数値である必要があります' })
        .int({ message: '満点は整数である必要があります' })
        .min(1, { message: '満点は1以上である必要があります' })
        .describe('満点'),
      timeLimitMinutes: z
        .number({ message: '制限時間は数値である必要があります' })
        .int({ message: '制限時間は整数である必要があります' })
        .min(1, { message: '制限時間は1分以上である必要があります' })
        .nullable()
        .describe('制限時間（分）'),
      availableFrom: z
        .string({ message: '受験可能開始日時は文字列である必要があります' })
        .datetime({ message: '受験可能開始日時はISO 8601形式の日時である必要があります' })
        .nullable()
        .describe('受験可能開始日時'),
      availableUntil: z
        .string({ message: '受験可能終了日時は文字列である必要があります' })
        .datetime({ message: '受験可能終了日時はISO 8601形式の日時である必要があります' })
        .nullable()
        .describe('受験可能終了日時'),
      isRandomOrder: z
        .boolean({ message: 'ランダム出題フラグはブール値である必要があります' })
        .describe('ランダム出題フラグ'),
      maxAttempts: z
        .number({ message: '最大受験回数は数値である必要があります' })
        .int({ message: '最大受験回数は整数である必要があります' })
        .min(1, { message: '最大受験回数は1以上である必要があります' })
        .nullable()
        .describe('最大受験回数'),
      showCorrectAnswers: z
        .boolean({ message: '正解表示フラグはブール値である必要があります' })
        .describe('正解表示フラグ'),
      showExplanations: z
        .boolean({ message: '解説表示フラグはブール値である必要があります' })
        .describe('解説表示フラグ'),
    },

    // ===================================
    // Question Schemas
    // ===================================
    question: {
      id: z
        .string({ message: '問題IDは文字列である必要があります' })
        .uuid({ message: '問題IDはUUIDである必要があります' })
        .describe('問題ID'),
      questionType: z
        .enum(['single', 'multiple'], { message: '問題タイプはsingle、multipleのいずれかである必要があります' })
        .describe('問題タイプ'),
      questionText: z
        .string({ message: '問題文は文字列である必要があります' })
        .min(1, { message: '問題文は必須です' })
        .max(5000, { message: '問題文は5000文字以内である必要があります' })
        .describe('問題文'),
      hint: z
        .string({ message: 'ヒントは文字列である必要があります' })
        .max(1000, { message: 'ヒントは1000文字以内である必要があります' })
        .nullable()
        .describe('ヒント'),
      points: z
        .number({ message: '配点は数値である必要があります' })
        .int({ message: '配点は整数である必要があります' })
        .min(1, { message: '配点は1以上である必要があります' })
        .describe('配点'),
    },

    // ===================================
    // Choice Schemas
    // ===================================
    choice: {
      id: z
        .string({ message: '選択肢IDは文字列である必要があります' })
        .uuid({ message: '選択肢IDはUUIDである必要があります' })
        .describe('選択肢ID'),
      choiceText: z
        .string({ message: '選択肢テキストは文字列である必要があります' })
        .min(1, { message: '選択肢テキストは必須です' })
        .max(2000, { message: '選択肢テキストは2000文字以内である必要があります' })
        .describe('選択肢テキスト'),
      isCorrect: z.boolean({ message: '正解フラグはブール値である必要があります' }).describe('正解フラグ'),
    },

    // ===================================
    // Explanation Schemas
    // ===================================
    explanation: {
      id: z
        .string({ message: '解説IDは文字列である必要があります' })
        .uuid({ message: '解説IDはUUIDである必要があります' })
        .describe('解説ID'),
      explanationText: z
        .string({ message: '解説テキストは文字列である必要があります' })
        .min(1, { message: '解説テキストは必須です' })
        .max(5000, { message: '解説テキストは5000文字以内である必要があります' })
        .describe('解説テキスト'),
    },

    // ===================================
    // Attempt Schemas
    // ===================================
    attempt: {
      id: z
        .string({ message: '受験記録IDは文字列である必要があります' })
        .uuid({ message: '受験記録IDはUUIDである必要があります' })
        .describe('受験記録ID'),
      attemptNumber: z
        .number({ message: '受験回数は数値である必要があります' })
        .int({ message: '受験回数は整数である必要があります' })
        .min(1, { message: '受験回数は1以上である必要があります' })
        .describe('受験回数'),
      status: z
        .enum(['in_progress', 'completed', 'abandoned'], {
          message: 'ステータスはin_progress、completed、abandonedのいずれかである必要があります',
        })
        .describe('ステータス'),
      score: z
        .number({ message: '得点は数値である必要があります' })
        .int({ message: '得点は整数である必要があります' })
        .min(0, { message: '得点は0以上である必要があります' })
        .describe('得点'),
      isPassed: z.boolean({ message: '合格フラグはブール値である必要があります' }).describe('合格フラグ'),
      timeSpentSeconds: z
        .number({ message: '所要時間は数値である必要があります' })
        .int({ message: '所要時間は整数である必要があります' })
        .min(0, { message: '所要時間は0以上である必要があります' })
        .describe('所要時間（秒）'),
    },

    // ===================================
    // Statistics Schemas
    // ===================================
    statistics: {
      totalAttempts: z
        .number({ message: '総受験回数は数値である必要があります' })
        .int({ message: '総受験回数は整数である必要があります' })
        .min(0, { message: '総受験回数は0以上である必要があります' })
        .describe('総受験回数'),
      totalQuestions: z
        .number({ message: '総問題数は数値である必要があります' })
        .int({ message: '総問題数は整数である必要があります' })
        .min(0, { message: '総問題数は0以上である必要があります' })
        .describe('総問題数'),
      correctAnswers: z
        .number({ message: '正解数は数値である必要があります' })
        .int({ message: '正解数は整数である必要があります' })
        .min(0, { message: '正解数は0以上である必要があります' })
        .describe('正解数'),
      accuracyRate: z
        .number({ message: '正答率は数値である必要があります' })
        .min(0, { message: '正答率は0以上である必要があります' })
        .max(100, { message: '正答率は100以下である必要があります' })
        .describe('正答率（%）'),
      averageScore: z
        .number({ message: '平均点は数値である必要があります' })
        .min(0, { message: '平均点は0以上である必要があります' })
        .describe('平均点'),
      passRate: z
        .number({ message: '合格率は数値である必要があります' })
        .min(0, { message: '合格率は0以上である必要があります' })
        .max(100, { message: '合格率は100以下である必要があります' })
        .describe('合格率（%）'),
    },

    // ===================================
    // Bookmark Schemas
    // ===================================
    bookmark: {
      note: z
        .string({ message: 'メモは文字列である必要があります' })
        .max(1000, { message: 'メモは1000文字以内である必要があります' })
        .nullable()
        .describe('メモ'),
    },
  },
} as const;

export const RESPONSE = {
  success: { success: 'OK' },
} as const;
