import { DrizzleDB } from '@/type.js';

/**
 * クエリビルダークラス
 * データベースアクセスパターンを `.with(db)` メソッドチェーンで実行可能にする
 *
 * @template T クエリの戻り値の型
 *
 * @example
 * ```typescript
 * // サービス関数での使用
 * export function createTag(input: CreateTagRequest) {
 *   return new QueryBuilder<Tag[]>(async (db) => {
 *     return await db.insert(examTags).values(input).returning();
 *   });
 * }
 *
 * // ルートハンドラーでの使用
 * const [tag] = await createTag(request.body).with(fastify.db);
 * ```
 */
export class QueryBuilder<T> {
  /**
   * @param executor データベース接続を受け取り、クエリを実行する関数
   */
  constructor(private executor: (db: DrizzleDB) => Promise<T>) {}

  /**
   * データベース接続を渡してクエリを実行
   *
   * @param db Drizzleデータベース接続オブジェクト
   * @returns クエリの実行結果
   */
  async with(db: DrizzleDB): Promise<T> {
    return await this.executor(db);
  }
}

/**
 * クエリビルダーを作成するヘルパー関数
 * 型推論を簡潔にするためのユーティリティ
 *
 * @template T クエリの戻り値の型
 * @param executor データベース接続を受け取り、クエリを実行する関数
 * @returns QueryBuilderインスタンス
 *
 * @example
 * ```typescript
 * export function createTag(input: CreateTagRequest) {
 *   return query(async (db) => {
 *     return await db.insert(examTags).values(input).returning();
 *   });
 * }
 * ```
 */
export function query<T>(executor: (db: DrizzleDB) => Promise<T>): QueryBuilder<T> {
  return new QueryBuilder(executor);
}
