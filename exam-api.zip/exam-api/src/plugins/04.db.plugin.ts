import { Logger } from 'drizzle-orm/logger';
import { drizzle } from 'drizzle-orm/node-postgres';
import { FastifyPluginAsync } from 'fastify';
import fp from 'fastify-plugin';
import { Pool } from 'pg';

import * as schema from '@/db/schema/index.js';
import { logger } from '@/utils/logger.util.js';

class CustomLogger implements Logger {
  logQuery(query: string, params: unknown[]): void {
    logger.info(`Query: ${query}`);
    logger.info(`Params: ${JSON.stringify(params)}`);
  }
}

const dbPlugin: FastifyPluginAsync = fp(async (fastify) => {
  const pool = new Pool({
    connectionString: fastify.config.DATABASE_URL,
  });
  const db = drizzle({ client: pool, schema, logger: new CustomLogger() });
  fastify.decorate('db', db);
});

export default dbPlugin;
