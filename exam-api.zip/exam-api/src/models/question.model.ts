import { z } from 'zod';

import { SCHEMA } from '@/utils/const.util.js';

// ===================================
// Choice Schema
// ===================================
export const choiceSchema = z.object({
  id: SCHEMA.z.choice.id,
  choiceText: SCHEMA.z.choice.choiceText,
  isCorrect: SCHEMA.z.choice.isCorrect,
  sortOrder: SCHEMA.z.common.sortOrder,
});

export type ChoiceSchema = z.infer<typeof choiceSchema>;

// ===================================
// Explanation Schema
// ===================================
export const explanationSchema = z.object({
  id: SCHEMA.z.explanation.id,
  explanationText: SCHEMA.z.explanation.explanationText,
});

export type ExplanationSchema = z.infer<typeof explanationSchema>;

// ===================================
// Question Create Request Schema
// ===================================
export const createQuestionRequestSchema = z.object({
  examId: SCHEMA.z.exam.id,
  questionType: SCHEMA.z.question.questionType,
  questionText: SCHEMA.z.question.questionText,
  hint: SCHEMA.z.question.hint,
  points: SCHEMA.z.question.points,
  sortOrder: SCHEMA.z.common.sortOrder,
  choices: z.array(
    z.object({
      choiceText: SCHEMA.z.choice.choiceText,
      isCorrect: SCHEMA.z.choice.isCorrect,
      sortOrder: SCHEMA.z.common.sortOrder,
    }),
  ),
  explanations: z
    .array(
      z.object({
        explanationText: SCHEMA.z.explanation.explanationText,
      }),
    )
    .optional(),
});

export type CreateQuestionRequest = z.infer<typeof createQuestionRequestSchema>;

// ===================================
// Question Update Request Schema
// ===================================
export const updateQuestionRequestSchema = z.object({
  questionType: SCHEMA.z.question.questionType.optional(),
  questionText: SCHEMA.z.question.questionText.optional(),
  hint: SCHEMA.z.question.hint,
  points: SCHEMA.z.question.points.optional(),
  sortOrder: SCHEMA.z.common.sortOrder.optional(),
  deletedAt: SCHEMA.z.common.deletedAt.nullable().optional(),
  choices: z
    .array(
      z.object({
        id: SCHEMA.z.choice.id.optional(),
        choiceText: SCHEMA.z.choice.choiceText,
        isCorrect: SCHEMA.z.choice.isCorrect,
        sortOrder: SCHEMA.z.common.sortOrder,
      }),
    )
    .optional(),
  explanations: z
    .array(
      z.object({
        id: SCHEMA.z.explanation.id.optional(),
        explanationText: SCHEMA.z.explanation.explanationText,
      }),
    )
    .optional(),
});

export type UpdateQuestionRequest = z.infer<typeof updateQuestionRequestSchema>;

// ===================================
// Question Response Schema
// ===================================
export const questionResponseSchema = z.object({
  id: SCHEMA.z.question.id,
  examId: SCHEMA.z.exam.id,
  questionType: SCHEMA.z.question.questionType,
  questionText: SCHEMA.z.question.questionText,
  hint: SCHEMA.z.question.hint,
  points: SCHEMA.z.question.points,
  sortOrder: SCHEMA.z.common.sortOrder,
  createdAt: SCHEMA.z.common.createdAt,
  updatedAt: SCHEMA.z.common.updatedAt.nullable(),
  deletedAt: SCHEMA.z.common.deletedAt.nullable(),
  choices: z.array(choiceSchema),
  explanations: z.array(explanationSchema).optional(),
});

export type QuestionResponse = z.infer<typeof questionResponseSchema>;

// ===================================
// Question List Response Schema
// ===================================
export const questionListResponseSchema = z.object({
  items: z.array(questionResponseSchema),
  pagination: z.object({
    page: SCHEMA.z.common.page,
    limit: SCHEMA.z.common.limit,
    total: z.number().int().min(0).describe('総件数'),
    totalPages: z.number().int().min(0).describe('総ページ数'),
  }),
});

export type QuestionListResponse = z.infer<typeof questionListResponseSchema>;
