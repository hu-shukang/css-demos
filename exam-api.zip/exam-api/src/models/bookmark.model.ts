import { z } from 'zod';

import { SCHEMA } from '@/utils/const.util.js';

// ===================================
// Bookmark Create Request Schema
// ===================================
export const createBookmarkRequestSchema = z.object({
  questionId: SCHEMA.z.question.id,
  note: SCHEMA.z.bookmark.note,
});

export type CreateBookmarkRequest = z.infer<typeof createBookmarkRequestSchema>;

// ===================================
// Bookmark Update Request Schema
// ===================================
export const updateBookmarkRequestSchema = z.object({
  note: SCHEMA.z.bookmark.note,
});

export type UpdateBookmarkRequest = z.infer<typeof updateBookmarkRequestSchema>;

// ===================================
// Bookmark Response Schema
// ===================================
export const bookmarkResponseSchema = z.object({
  id: SCHEMA.z.common.id,
  userId: SCHEMA.z.user.id,
  questionId: SCHEMA.z.question.id,
  note: SCHEMA.z.bookmark.note,
  createdAt: SCHEMA.z.common.createdAt,
  updatedAt: SCHEMA.z.common.updatedAt.nullable(),
  question: z
    .object({
      id: SCHEMA.z.question.id,
      questionText: SCHEMA.z.question.questionText,
      questionType: SCHEMA.z.question.questionType,
      points: SCHEMA.z.question.points,
    })
    .optional()
    .describe('問題情報'),
});

export type BookmarkResponse = z.infer<typeof bookmarkResponseSchema>;

// ===================================
// Bookmark List Response Schema
// ===================================
export const bookmarkListResponseSchema = z.object({
  items: z.array(bookmarkResponseSchema),
  pagination: z.object({
    page: SCHEMA.z.common.page,
    limit: SCHEMA.z.common.limit,
    total: z.number().int().min(0).describe('総件数'),
    totalPages: z.number().int().min(0).describe('総ページ数'),
  }),
});

export type BookmarkListResponse = z.infer<typeof bookmarkListResponseSchema>;
