import { z } from 'zod';

import { SCHEMA } from '@/utils/const.util.js';

// ===================================
// Answer Schema
// ===================================
export const answerSchema = z.object({
  id: SCHEMA.z.common.id,
  questionId: SCHEMA.z.question.id,
  selectedChoiceIds: z.array(SCHEMA.z.choice.id).describe('選択した選択肢IDリスト'),
  isCorrect: z.boolean().describe('正解フラグ'),
  pointsAwarded: z.number().int().min(0).describe('獲得点数'),
  answeredAt: z.string().datetime().describe('回答日時'),
});

export type AnswerSchema = z.infer<typeof answerSchema>;

// ===================================
// Start Attempt Request Schema
// ===================================
export const startAttemptRequestSchema = z.object({
  examId: SCHEMA.z.exam.id,
});

export type StartAttemptRequest = z.infer<typeof startAttemptRequestSchema>;

// ===================================
// Submit Answer Request Schema
// ===================================
export const submitAnswerRequestSchema = z.object({
  attemptId: SCHEMA.z.attempt.id,
  questionId: SCHEMA.z.question.id,
  selectedChoiceIds: z.array(SCHEMA.z.choice.id).describe('選択した選択肢IDリスト'),
});

export type SubmitAnswerRequest = z.infer<typeof submitAnswerRequestSchema>;

// ===================================
// Complete Attempt Request Schema
// ===================================
export const completeAttemptRequestSchema = z.object({
  attemptId: SCHEMA.z.attempt.id,
});

export type CompleteAttemptRequest = z.infer<typeof completeAttemptRequestSchema>;

// ===================================
// Attempt Response Schema
// ===================================
export const attemptResponseSchema = z.object({
  id: SCHEMA.z.attempt.id,
  userId: SCHEMA.z.user.id,
  examId: SCHEMA.z.exam.id,
  attemptNumber: SCHEMA.z.attempt.attemptNumber,
  status: SCHEMA.z.attempt.status,
  score: SCHEMA.z.attempt.score,
  isPassed: SCHEMA.z.attempt.isPassed,
  timeSpentSeconds: SCHEMA.z.attempt.timeSpentSeconds,
  startedAt: z.string().datetime().describe('開始日時'),
  completedAt: z.string().datetime().nullable().describe('完了日時'),
  createdAt: SCHEMA.z.common.createdAt,
  updatedAt: SCHEMA.z.common.updatedAt.nullable(),
});

export type AttemptResponse = z.infer<typeof attemptResponseSchema>;

// ===================================
// Attempt Detail Response Schema
// ===================================
export const attemptDetailResponseSchema = z.object({
  attempt: attemptResponseSchema,
  answers: z.array(answerSchema),
});

export type AttemptDetailResponse = z.infer<typeof attemptDetailResponseSchema>;
