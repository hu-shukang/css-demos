import { z } from 'zod';

import { SCHEMA } from '@/utils/const.util.js';

// ===================================
// Category Create Request Schema
// ===================================
export const createCategoryRequestSchema = z.object({
  parentId: SCHEMA.z.category.parentId,
  name: SCHEMA.z.category.name,
  description: SCHEMA.z.category.description,
  sortOrder: SCHEMA.z.common.sortOrder,
});

export type CreateCategoryRequest = z.infer<typeof createCategoryRequestSchema>;

// ===================================
// Category Update Request Schema
// ===================================
export const updateCategoryRequestSchema = z.object({
  name: SCHEMA.z.category.name.optional(),
  description: SCHEMA.z.category.description,
  sortOrder: SCHEMA.z.common.sortOrder.optional(),
  deletedAt: SCHEMA.z.common.deletedAt.nullable().optional(),
});

export type UpdateCategoryRequest = z.infer<typeof updateCategoryRequestSchema>;

// ===================================
// Category Response Schema
// ===================================
export const categoryResponseSchema = z.object({
  id: SCHEMA.z.category.id,
  parentId: SCHEMA.z.category.parentId,
  name: SCHEMA.z.category.name,
  description: SCHEMA.z.category.description,
  sortOrder: SCHEMA.z.common.sortOrder,
  createdAt: SCHEMA.z.common.createdAt,
  updatedAt: SCHEMA.z.common.updatedAt.nullable(),
  deletedAt: SCHEMA.z.common.deletedAt.nullable(),
});

export type CategoryResponse = z.infer<typeof categoryResponseSchema>;

// ===================================
// Category List Response Schema
// ===================================
export const categoryListResponseSchema = z.object({
  items: z.array(categoryResponseSchema),
  pagination: z.object({
    page: SCHEMA.z.common.page,
    limit: SCHEMA.z.common.limit,
    total: z.number().int().min(0).describe('総件数'),
    totalPages: z.number().int().min(0).describe('総ページ数'),
  }),
});

export type CategoryListResponse = z.infer<typeof categoryListResponseSchema>;
