import { z } from 'zod';

import { SCHEMA } from '@/utils/const.util.js';

// ===================================
// User Statistics Response Schema
// ===================================
export const userStatisticsResponseSchema = z.object({
  totalAttempts: SCHEMA.z.statistics.totalAttempts,
  totalQuestions: SCHEMA.z.statistics.totalQuestions,
  correctAnswers: SCHEMA.z.statistics.correctAnswers,
  accuracyRate: SCHEMA.z.statistics.accuracyRate,
  averageScore: SCHEMA.z.statistics.averageScore,
  totalTimeSpentSeconds: SCHEMA.z.attempt.timeSpentSeconds,
});

export type UserStatisticsResponse = z.infer<typeof userStatisticsResponseSchema>;

// ===================================
// Exam Statistics Response Schema
// ===================================
export const examStatisticsResponseSchema = z.object({
  examId: SCHEMA.z.exam.id,
  totalAttempts: SCHEMA.z.statistics.totalAttempts,
  averageScore: SCHEMA.z.statistics.averageScore,
  passRate: SCHEMA.z.statistics.passRate,
  averageTimeSpentSeconds: z.number().min(0).describe('平均所要時間（秒）'),
});

export type ExamStatisticsResponse = z.infer<typeof examStatisticsResponseSchema>;

// ===================================
// Question Statistics Response Schema
// ===================================
export const questionStatisticsResponseSchema = z.object({
  questionId: SCHEMA.z.question.id,
  totalAttempts: SCHEMA.z.statistics.totalAttempts,
  correctCount: SCHEMA.z.statistics.correctAnswers,
  incorrectCount: z.number().int().min(0).describe('誤答数'),
  accuracyRate: SCHEMA.z.statistics.accuracyRate,
});

export type QuestionStatisticsResponse = z.infer<typeof questionStatisticsResponseSchema>;
