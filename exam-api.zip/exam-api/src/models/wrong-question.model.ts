import { z } from 'zod';

import { SCHEMA } from '@/utils/const.util.js';

// ===================================
// Wrong Question Response Schema
// ===================================
export const wrongQuestionResponseSchema = z.object({
  id: SCHEMA.z.common.id,
  userId: SCHEMA.z.user.id,
  questionId: SCHEMA.z.question.id,
  incorrectCount: z.number().int().min(1).describe('誤答回数'),
  lastIncorrectAt: z.string().datetime().describe('最終誤答日時'),
  isResolved: z.boolean().describe('解決済みフラグ'),
  resolvedAt: z.string().datetime().nullable().describe('解決日時'),
  createdAt: SCHEMA.z.common.createdAt,
  updatedAt: SCHEMA.z.common.updatedAt.nullable(),
  question: z
    .object({
      id: SCHEMA.z.question.id,
      questionText: SCHEMA.z.question.questionText,
      questionType: SCHEMA.z.question.questionType,
      points: SCHEMA.z.question.points,
    })
    .optional()
    .describe('問題情報'),
});

export type WrongQuestionResponse = z.infer<typeof wrongQuestionResponseSchema>;

// ===================================
// Wrong Question List Response Schema
// ===================================
export const wrongQuestionListResponseSchema = z.object({
  items: z.array(wrongQuestionResponseSchema),
  pagination: z.object({
    page: SCHEMA.z.common.page,
    limit: SCHEMA.z.common.limit,
    total: z.number().int().min(0).describe('総件数'),
    totalPages: z.number().int().min(0).describe('総ページ数'),
  }),
});

export type WrongQuestionListResponse = z.infer<typeof wrongQuestionListResponseSchema>;
