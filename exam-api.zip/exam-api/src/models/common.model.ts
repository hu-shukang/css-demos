import { z } from 'zod';

import { SCHEMA } from '@/utils/const.util.js';

// ===================================
// Pagination Query Schema
// ===================================
export const paginationQuerySchema = z.object({
  page: SCHEMA.z.common.page,
  limit: SCHEMA.z.common.limit,
});

export type PaginationQuery = z.infer<typeof paginationQuerySchema>;

// ===================================
// Pagination Meta Schema
// ===================================
export const paginationMetaSchema = z.object({
  page: SCHEMA.z.common.page,
  limit: SCHEMA.z.common.limit,
  total: z.number().int().min(0).describe('総件数'),
  totalPages: z.number().int().min(0).describe('総ページ数'),
});

export type PaginationMeta = z.infer<typeof paginationMetaSchema>;

// ===================================
// 200 Response Schema
// ===================================
export const successSchema = z
  .object({
    success: SCHEMA.z.common.success,
  })
  .describe('Success');

// ===================================
// 400 Response Schema
// ===================================
export const badRequestSchema = z
  .object({
    error: SCHEMA.z.common.error,
    details: z.array(
      z.object({
        path: SCHEMA.z.common.path,
        message: SCHEMA.z.common.message,
      }),
    ),
  })
  .describe('Bad Request');

// ===================================
// 404 Response Schema
// ===================================
export const notFoundSchema = z
  .object({
    error: SCHEMA.z.common.error,
    message: SCHEMA.z.common.message,
  })
  .describe('Not Found');
