import { z } from 'zod';

import { SCHEMA } from '@/utils/const.util.js';

// ===================================
// Tag Create Request Schema
// ===================================
export const createTagRequestSchema = z.object({
  name: SCHEMA.z.tag.name,
});

export type CreateTagRequest = z.infer<typeof createTagRequestSchema>;

// ===================================
// Tag Update Request Schema
// ===================================
export const updateTagRequestSchema = z.object({
  name: SCHEMA.z.tag.name.optional(),
  deletedAt: SCHEMA.z.common.deletedAt.nullish(),
});

export type UpdateTagRequest = z.infer<typeof updateTagRequestSchema>;

// ===================================
// Tag Response Schema
// ===================================
export const tagResponseSchema = z.object({
  id: SCHEMA.z.tag.id,
  name: SCHEMA.z.tag.name,
  createdAt: SCHEMA.z.common.createdAt,
  updatedAt: SCHEMA.z.common.updatedAt.nullable(),
  deletedAt: SCHEMA.z.common.deletedAt.nullish(),
});

export type TagResponse = z.infer<typeof tagResponseSchema>;

// ===================================
// Tag List Response Schema
// ===================================
export const tagListResponseSchema = z.object({
  items: z.array(tagResponseSchema),
  pagination: z.object({
    page: SCHEMA.z.common.page,
    limit: SCHEMA.z.common.limit,
    total: z.number().int().min(0).describe('総件数'),
    totalPages: z.number().int().min(0).describe('総ページ数'),
  }),
});

export type TagListResponse = z.infer<typeof tagListResponseSchema>;
