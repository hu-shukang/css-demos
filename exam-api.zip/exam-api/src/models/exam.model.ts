import { z } from 'zod';

import { SCHEMA } from '@/utils/const.util.js';

// ===================================
// Exam Create Request Schema
// ===================================
export const createExamRequestSchema = z.object({
  categoryId: SCHEMA.z.category.id,
  title: SCHEMA.z.exam.title,
  description: SCHEMA.z.exam.description,
  instructions: SCHEMA.z.exam.instructions,
  status: SCHEMA.z.exam.status,
  difficultyLevel: SCHEMA.z.exam.difficultyLevel,
  passingScore: SCHEMA.z.exam.passingScore,
  totalScore: SCHEMA.z.exam.totalScore,
  timeLimitMinutes: SCHEMA.z.exam.timeLimitMinutes,
  availableFrom: SCHEMA.z.exam.availableFrom,
  availableUntil: SCHEMA.z.exam.availableUntil,
  isRandomOrder: SCHEMA.z.exam.isRandomOrder,
  maxAttempts: SCHEMA.z.exam.maxAttempts,
  showCorrectAnswers: SCHEMA.z.exam.showCorrectAnswers,
  showExplanations: SCHEMA.z.exam.showExplanations,
  tagIds: z.array(SCHEMA.z.tag.id).optional().describe('タグIDリスト'),
});

export type CreateExamRequest = z.infer<typeof createExamRequestSchema>;

// ===================================
// Exam Update Request Schema
// ===================================
export const updateExamRequestSchema = z.object({
  categoryId: SCHEMA.z.category.id.optional(),
  title: SCHEMA.z.exam.title.optional(),
  description: SCHEMA.z.exam.description,
  instructions: SCHEMA.z.exam.instructions,
  status: SCHEMA.z.exam.status.optional(),
  difficultyLevel: SCHEMA.z.exam.difficultyLevel,
  passingScore: SCHEMA.z.exam.passingScore.optional(),
  totalScore: SCHEMA.z.exam.totalScore.optional(),
  timeLimitMinutes: SCHEMA.z.exam.timeLimitMinutes,
  availableFrom: SCHEMA.z.exam.availableFrom,
  availableUntil: SCHEMA.z.exam.availableUntil,
  isRandomOrder: SCHEMA.z.exam.isRandomOrder.optional(),
  maxAttempts: SCHEMA.z.exam.maxAttempts,
  showCorrectAnswers: SCHEMA.z.exam.showCorrectAnswers.optional(),
  showExplanations: SCHEMA.z.exam.showExplanations.optional(),
  deletedAt: SCHEMA.z.common.deletedAt.nullable().optional(),
  tagIds: z.array(SCHEMA.z.tag.id).optional().describe('タグIDリスト'),
});

export type UpdateExamRequest = z.infer<typeof updateExamRequestSchema>;

// ===================================
// Exam Response Schema
// ===================================
export const examResponseSchema = z.object({
  id: SCHEMA.z.exam.id,
  categoryId: SCHEMA.z.category.id,
  title: SCHEMA.z.exam.title,
  description: SCHEMA.z.exam.description,
  instructions: SCHEMA.z.exam.instructions,
  status: SCHEMA.z.exam.status,
  difficultyLevel: SCHEMA.z.exam.difficultyLevel,
  passingScore: SCHEMA.z.exam.passingScore,
  totalScore: SCHEMA.z.exam.totalScore,
  timeLimitMinutes: SCHEMA.z.exam.timeLimitMinutes,
  availableFrom: SCHEMA.z.exam.availableFrom,
  availableUntil: SCHEMA.z.exam.availableUntil,
  isRandomOrder: SCHEMA.z.exam.isRandomOrder,
  maxAttempts: SCHEMA.z.exam.maxAttempts,
  showCorrectAnswers: SCHEMA.z.exam.showCorrectAnswers,
  showExplanations: SCHEMA.z.exam.showExplanations,
  createdAt: SCHEMA.z.common.createdAt,
  updatedAt: SCHEMA.z.common.updatedAt.nullable(),
  deletedAt: SCHEMA.z.common.deletedAt.nullable(),
  tags: z
    .array(
      z.object({
        id: SCHEMA.z.tag.id,
        name: SCHEMA.z.tag.name,
      }),
    )
    .optional()
    .describe('タグリスト'),
});

export type ExamResponse = z.infer<typeof examResponseSchema>;

// ===================================
// Exam List Response Schema
// ===================================
export const examListResponseSchema = z.object({
  items: z.array(examResponseSchema),
  pagination: z.object({
    page: SCHEMA.z.common.page,
    limit: SCHEMA.z.common.limit,
    total: z.number().int().min(0).describe('総件数'),
    totalPages: z.number().int().min(0).describe('総ページ数'),
  }),
});

export type ExamListResponse = z.infer<typeof examListResponseSchema>;
