import { relations } from 'drizzle-orm';
import { pgTable, primaryKey, timestamp, uuid, varchar } from 'drizzle-orm/pg-core';

import { exams } from './exams.schema.js';

/**
 * Exam Tags Table
 * 試験タグテーブル
 * 試験を横断的に分類するためのタグ情報を管理
 */
export const examTags = pgTable('exam_tags', {
  /** タグID（UUID） */
  id: uuid('id').primaryKey().defaultRandom(),
  /** タグ名 */
  name: varchar('name', { length: 100 }).notNull(),
  /** 作成日時 */
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  /** 更新日時 */
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

/**
 * Exam Tag Relations Table (Many-to-Many)
 * 試験タグ関連テーブル
 * 試験とタグの多対多関係を管理
 */
export const examTagRelations = pgTable(
  'exam_tag_relations',
  {
    /** 試験ID */
    examId: uuid('exam_id')
      .notNull()
      .references(() => exams.id, { onDelete: 'cascade' }),
    /** タグID */
    tagId: uuid('tag_id')
      .notNull()
      .references(() => examTags.id, { onDelete: 'cascade' }),
    /** 作成日時 */
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [primaryKey({ columns: [table.examId, table.tagId] })],
);

// ===================================
// Relations
// ===================================
export const examTagsRelations = relations(examTags, ({ many }) => ({
  examRelations: many(examTagRelations),
}));

export const examTagRelationsRelations = relations(examTagRelations, ({ one }) => ({
  exam: one(exams, {
    fields: [examTagRelations.examId],
    references: [exams.id],
  }),
  tag: one(examTags, {
    fields: [examTagRelations.tagId],
    references: [examTags.id],
  }),
}));

// ===================================
// Types
// ===================================
export type ExamTag = typeof examTags.$inferSelect;
export type NewExamTag = typeof examTags.$inferInsert;
export type ExamTagRelation = typeof examTagRelations.$inferSelect;
export type NewExamTagRelation = typeof examTagRelations.$inferInsert;
