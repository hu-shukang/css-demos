import { relations } from 'drizzle-orm';
import { pgTable, timestamp, uuid, varchar } from 'drizzle-orm/pg-core';

import { examAttempts } from './attempts.schema.js';
import { exams } from './exams.schema.js';
import { userStatistics } from './statistics.schema.js';

/**
 * Users Table
 * ユーザーテーブル
 * AWS Cognitoで認証されたユーザーの基本情報を管理
 */
export const users = pgTable('users', {
  /** ユーザーID（UUID） */
  id: uuid('id').primaryKey().defaultRandom(),
  /** Cognito Sub（AWS Cognitoのユーザー識別子） */
  cognitoSub: varchar('cognito_sub', { length: 255 }).notNull().unique(),
  /** ユーザー名 */
  username: varchar('username', { length: 100 }).notNull(),
  /** メールアドレス */
  email: varchar('email', { length: 255 }).notNull().unique(),
  /** 優先言語（ja/en/zh） */
  preferredLanguage: varchar('preferred_language', { length: 10 }).notNull().default('ja'),
  /** 作成日時 */
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  /** 更新日時 */
  updatedAt: timestamp('updated_at', { withTimezone: true }),
  /** 削除日時（論理削除） */
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
});

// ===================================
// Relations
// ===================================
export const usersRelations = relations(users, ({ many }) => ({
  exams: many(exams),
  examAttempts: many(examAttempts),
  userStatistics: many(userStatistics),
}));

// ===================================
// Types
// ===================================
export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
