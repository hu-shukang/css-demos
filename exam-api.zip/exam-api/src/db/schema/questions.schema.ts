import { relations } from 'drizzle-orm';
import { boolean, integer, pgTable, text, timestamp, uuid, varchar } from 'drizzle-orm/pg-core';

import { bookmarks, userAnswers, wrongQuestions } from './attempts.schema.js';
import { exams } from './exams.schema.js';
import { questionStatistics } from './statistics.schema.js';

/**
 * Questions Table
 * 問題テーブル
 * 試験の問題情報を管理
 */
export const questions = pgTable('questions', {
  /** 問題ID（UUID） */
  id: uuid('id').primaryKey().defaultRandom(),
  /** 試験ID */
  examId: uuid('exam_id')
    .notNull()
    .references(() => exams.id, { onDelete: 'cascade' }),
  /** 問題タイプ（single/multiple） */
  questionType: varchar('question_type', { length: 20 }).notNull(),
  /** 問題文 */
  questionText: text('question_text').notNull(),
  /** ヒント */
  hint: text('hint'),
  /** 配点 */
  points: integer('points').notNull().default(1),
  /** 表示順序 */
  sortOrder: integer('sort_order').notNull().default(0),
  /** 作成日時 */
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  /** 更新日時 */
  updatedAt: timestamp('updated_at', { withTimezone: true }),
  /** 削除日時（論理削除） */
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
});

/**
 * Choices Table
 * 選択肢テーブル
 * 問題の選択肢情報を管理
 */
export const choices = pgTable('choices', {
  /** 選択肢ID（UUID） */
  id: uuid('id').primaryKey().defaultRandom(),
  /** 問題ID */
  questionId: uuid('question_id')
    .notNull()
    .references(() => questions.id, { onDelete: 'cascade' }),
  /** 選択肢テキスト */
  choiceText: text('choice_text').notNull(),
  /** 正解かどうか */
  isCorrect: boolean('is_correct').notNull().default(false),
  /** 表示順序 */
  sortOrder: integer('sort_order').notNull().default(0),
  /** 作成日時 */
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  /** 更新日時 */
  updatedAt: timestamp('updated_at', { withTimezone: true }),
  /** 削除日時（論理削除） */
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
});

/**
 * Explanations Table
 * 解説テーブル
 * 問題または選択肢の解説情報を管理
 */
export const explanations = pgTable('explanations', {
  /** 解説ID（UUID） */
  id: uuid('id').primaryKey().defaultRandom(),
  /** 問題ID */
  questionId: uuid('question_id')
    .notNull()
    .references(() => questions.id, { onDelete: 'cascade' }),
  /** 選択肢ID（選択肢ごとの解説の場合） */
  choiceId: uuid('choice_id').references(() => choices.id, { onDelete: 'cascade' }),
  /** 解説テキスト */
  explanationText: text('explanation_text').notNull(),
  /** 作成日時 */
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  /** 更新日時 */
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Relations
// ===================================
export const questionsRelations = relations(questions, ({ one, many }) => ({
  exam: one(exams, {
    fields: [questions.examId],
    references: [exams.id],
  }),
  choices: many(choices),
  explanations: many(explanations),
  userAnswers: many(userAnswers),
  wrongQuestions: many(wrongQuestions),
  bookmarks: many(bookmarks),
  statistics: one(questionStatistics),
}));

export const choicesRelations = relations(choices, ({ one, many }) => ({
  question: one(questions, {
    fields: [choices.questionId],
    references: [questions.id],
  }),
  explanations: many(explanations),
  userAnswers: many(userAnswers),
}));

export const explanationsRelations = relations(explanations, ({ one }) => ({
  question: one(questions, {
    fields: [explanations.questionId],
    references: [questions.id],
  }),
  choice: one(choices, {
    fields: [explanations.choiceId],
    references: [choices.id],
  }),
}));

// ===================================
// Types
// ===================================
export type Question = typeof questions.$inferSelect;
export type NewQuestion = typeof questions.$inferInsert;
export type Choice = typeof choices.$inferSelect;
export type NewChoice = typeof choices.$inferInsert;
export type Explanation = typeof explanations.$inferSelect;
export type NewExplanation = typeof explanations.$inferInsert;
