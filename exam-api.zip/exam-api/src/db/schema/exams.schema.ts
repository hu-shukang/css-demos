import { relations } from 'drizzle-orm';
import { boolean, integer, pgTable, text, timestamp, uuid, varchar } from 'drizzle-orm/pg-core';

import { examAttempts } from './attempts.schema.js';
import { examCategories } from './categories.schema.js';
import { questions } from './questions.schema.js';
import { examStatistics } from './statistics.schema.js';
import { examTagRelations } from './tags.schema.js';
import { users } from './users.schema.js';

/**
 * Exams Table
 * 試験テーブル
 * 試験の基本情報と設定を管理
 */
export const exams = pgTable('exams', {
  /** 試験ID（UUID） */
  id: uuid('id').primaryKey().defaultRandom(),
  /** カテゴリID */
  categoryId: uuid('category_id').references(() => examCategories.id, { onDelete: 'set null' }),
  /** 作成者ID */
  createdBy: uuid('created_by')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  /** 試験タイトル */
  title: varchar('title', { length: 500 }).notNull(),
  /** 試験説明 */
  description: text('description'),
  /** 受験の指示・注意事項 */
  instructions: text('instructions'),
  /** ステータス（draft/published/archived） */
  status: varchar('status', { length: 20 }).notNull().default('draft'),
  /** 難易度（beginner/intermediate/advanced） */
  difficultyLevel: varchar('difficulty_level', { length: 20 }),
  /** 合格点 */
  passingScore: integer('passing_score').notNull(),
  /** 満点 */
  totalScore: integer('total_score').notNull(),
  /** 制限時間（分） */
  timeLimitMinutes: integer('time_limit_minutes'),
  /** 公開開始日時 */
  availableFrom: timestamp('available_from', { withTimezone: true }),
  /** 公開終了日時 */
  availableUntil: timestamp('available_until', { withTimezone: true }),
  /** 問題をランダム順で表示するか */
  isRandomOrder: boolean('is_random_order').notNull().default(false),
  /** 最大受験回数 */
  maxAttempts: integer('max_attempts'),
  /** 正解を表示するか */
  showCorrectAnswers: boolean('show_correct_answers').notNull().default(true),
  /** 解説を表示するか */
  showExplanations: boolean('show_explanations').notNull().default(true),
  /** 作成日時 */
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  /** 更新日時 */
  updatedAt: timestamp('updated_at', { withTimezone: true }),
  /** 削除日時（論理削除） */
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
});

// ===================================
// Relations
// ===================================
export const examsRelations = relations(exams, ({ one, many }) => ({
  category: one(examCategories, {
    fields: [exams.categoryId],
    references: [examCategories.id],
  }),
  creator: one(users, {
    fields: [exams.createdBy],
    references: [users.id],
  }),
  tagRelations: many(examTagRelations),
  questions: many(questions),
  examAttempts: many(examAttempts),
  statistics: one(examStatistics),
}));

// ===================================
// Types
// ===================================
export type Exam = typeof exams.$inferSelect;
export type NewExam = typeof exams.$inferInsert;
