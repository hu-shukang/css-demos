import { relations } from 'drizzle-orm';
import { integer, pgTable, text, timestamp, uuid, varchar } from 'drizzle-orm/pg-core';

import { exams } from './exams.schema.js';
import { userStatistics } from './statistics.schema.js';

/**
 * Exam Categories Table
 * 試験カテゴリテーブル
 * 試験を階層的に分類するためのカテゴリ情報を管理
 */
export const examCategories = pgTable('exam_categories', {
  /** カテゴリID（UUID） */
  id: uuid('id').primaryKey().defaultRandom(),
  /** 親カテゴリID（階層構造用） */
  parentId: uuid('parent_id'),
  /** カテゴリ名 */
  name: varchar('name', { length: 200 }).notNull(),
  /** カテゴリ説明 */
  description: text('description'),
  /** 表示順序 */
  sortOrder: integer('sort_order').notNull().default(0),
  /** 作成日時 */
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  /** 更新日時 */
  updatedAt: timestamp('updated_at', { withTimezone: true }),
  /** 削除日時（論理削除） */
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
});

// ===================================
// Relations
// ===================================
export const examCategoriesRelations = relations(examCategories, ({ one, many }) => ({
  parent: one(examCategories, {
    fields: [examCategories.parentId],
    references: [examCategories.id],
    relationName: 'category_parent',
  }),
  children: many(examCategories, { relationName: 'category_parent' }),
  exams: many(exams),
  userStatistics: many(userStatistics),
}));

// ===================================
// Types
// ===================================
export type ExamCategory = typeof examCategories.$inferSelect;
export type NewExamCategory = typeof examCategories.$inferInsert;
