import { relations } from 'drizzle-orm';
import { boolean, integer, pgTable, text, timestamp, unique, uuid, varchar } from 'drizzle-orm/pg-core';

import { exams } from './exams.schema.js';
import { choices, questions } from './questions.schema.js';
import { users } from './users.schema.js';

/**
 * Exam Attempts Table
 * 受験記録テーブル
 * ユーザーの試験受験履歴を管理
 */
export const examAttempts = pgTable('exam_attempts', {
  /** 受験記録ID（UUID） */
  id: uuid('id').primaryKey().defaultRandom(),
  /** 試験ID */
  examId: uuid('exam_id')
    .notNull()
    .references(() => exams.id, { onDelete: 'cascade' }),
  /** ユーザーID */
  userId: uuid('user_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  /** 受験回数 */
  attemptNumber: integer('attempt_number').notNull(),
  /** ステータス（in_progress/completed/abandoned） */
  status: varchar('status', { length: 20 }).notNull().default('in_progress'),
  /** 獲得点数 */
  score: integer('score'),
  /** 満点 */
  totalScore: integer('total_score'),
  /** 合格したかどうか */
  isPassed: boolean('is_passed'),
  /** 開始日時 */
  startedAt: timestamp('started_at', { withTimezone: true }).notNull().defaultNow(),
  /** 完了日時 */
  completedAt: timestamp('completed_at', { withTimezone: true }),
  /** 所要時間（秒） */
  timeSpentSeconds: integer('time_spent_seconds'),
  /** 作成日時 */
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  /** 更新日時 */
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

/**
 * User Answers Table
 * ユーザー回答テーブル
 * 受験時のユーザーの各問題への回答を管理
 */
export const userAnswers = pgTable('user_answers', {
  /** 回答ID（UUID） */
  id: uuid('id').primaryKey().defaultRandom(),
  /** 受験記録ID */
  attemptId: uuid('attempt_id')
    .notNull()
    .references(() => examAttempts.id, { onDelete: 'cascade' }),
  /** 問題ID */
  questionId: uuid('question_id')
    .notNull()
    .references(() => questions.id, { onDelete: 'cascade' }),
  /** 選択した選択肢ID */
  choiceId: uuid('choice_id')
    .notNull()
    .references(() => choices.id, { onDelete: 'cascade' }),
  /** 正解かどうか */
  isCorrect: boolean('is_correct').notNull(),
  /** 獲得点数 */
  pointsEarned: integer('points_earned').notNull().default(0),
  /** 回答日時 */
  answeredAt: timestamp('answered_at', { withTimezone: true }).notNull().defaultNow(),
  /** 作成日時 */
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  /** 更新日時 */
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

/**
 * Wrong Questions Table
 * 間違えた問題テーブル
 * ユーザーが間違えた問題を記録し、復習機能を提供
 */
export const wrongQuestions = pgTable(
  'wrong_questions',
  {
    /** 間違い記録ID（UUID） */
    id: uuid('id').primaryKey().defaultRandom(),
    /** ユーザーID */
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    /** 問題ID */
    questionId: uuid('question_id')
      .notNull()
      .references(() => questions.id, { onDelete: 'cascade' }),
    /** 間違えた回数 */
    wrongCount: integer('wrong_count').notNull().default(1),
    /** 最後に間違えた日時 */
    lastWrongAt: timestamp('last_wrong_at', { withTimezone: true }).notNull().defaultNow(),
    /** マスターしたかどうか */
    isMastered: boolean('is_mastered').notNull().default(false),
    /** マスターした日時 */
    masteredAt: timestamp('mastered_at', { withTimezone: true }),
    /** 作成日時 */
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    /** 更新日時 */
    updatedAt: timestamp('updated_at', { withTimezone: true }),
  },
  (table) => [unique('unique_user_question').on(table.userId, table.questionId)],
);

/**
 * Bookmarks Table
 * ブックマークテーブル
 * ユーザーが後で見返したい問題をブックマーク
 */
export const bookmarks = pgTable(
  'bookmarks',
  {
    /** ブックマークID（UUID） */
    id: uuid('id').primaryKey().defaultRandom(),
    /** ユーザーID */
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    /** 問題ID */
    questionId: uuid('question_id')
      .notNull()
      .references(() => questions.id, { onDelete: 'cascade' }),
    /** メモ */
    note: text('note'),
    /** 作成日時 */
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    /** 更新日時 */
    updatedAt: timestamp('updated_at', { withTimezone: true }),
  },
  (table) => [unique('unique_user_question_bookmark').on(table.userId, table.questionId)],
);

// ===================================
// Relations
// ===================================
export const examAttemptsRelations = relations(examAttempts, ({ one, many }) => ({
  exam: one(exams, {
    fields: [examAttempts.examId],
    references: [exams.id],
  }),
  user: one(users, {
    fields: [examAttempts.userId],
    references: [users.id],
  }),
  userAnswers: many(userAnswers),
}));

export const userAnswersRelations = relations(userAnswers, ({ one }) => ({
  attempt: one(examAttempts, {
    fields: [userAnswers.attemptId],
    references: [examAttempts.id],
  }),
  question: one(questions, {
    fields: [userAnswers.questionId],
    references: [questions.id],
  }),
  choice: one(choices, {
    fields: [userAnswers.choiceId],
    references: [choices.id],
  }),
}));

export const wrongQuestionsRelations = relations(wrongQuestions, ({ one }) => ({
  user: one(users, {
    fields: [wrongQuestions.userId],
    references: [users.id],
  }),
  question: one(questions, {
    fields: [wrongQuestions.questionId],
    references: [questions.id],
  }),
}));

export const bookmarksRelations = relations(bookmarks, ({ one }) => ({
  user: one(users, {
    fields: [bookmarks.userId],
    references: [users.id],
  }),
  question: one(questions, {
    fields: [bookmarks.questionId],
    references: [questions.id],
  }),
}));

// ===================================
// Types
// ===================================
export type ExamAttempt = typeof examAttempts.$inferSelect;
export type NewExamAttempt = typeof examAttempts.$inferInsert;
export type UserAnswer = typeof userAnswers.$inferSelect;
export type NewUserAnswer = typeof userAnswers.$inferInsert;
export type WrongQuestion = typeof wrongQuestions.$inferSelect;
export type NewWrongQuestion = typeof wrongQuestions.$inferInsert;
export type Bookmark = typeof bookmarks.$inferSelect;
export type NewBookmark = typeof bookmarks.$inferInsert;
