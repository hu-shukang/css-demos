import { relations } from 'drizzle-orm';
import { decimal, integer, pgTable, timestamp, unique, uuid } from 'drizzle-orm/pg-core';

import { examCategories } from './categories.schema.js';
import { exams } from './exams.schema.js';
import { questions } from './questions.schema.js';
import { users } from './users.schema.js';

/**
 * User Statistics Table
 * ユーザー統計テーブル
 * カテゴリごとのユーザーの学習統計を集計
 */
export const userStatistics = pgTable(
  'user_statistics',
  {
    /** 統計ID（UUID） */
    id: uuid('id').primaryKey().defaultRandom(),
    /** ユーザーID */
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    /** カテゴリID */
    categoryId: uuid('category_id').references(() => examCategories.id, { onDelete: 'cascade' }),
    /** 総受験回数 */
    totalAttempts: integer('total_attempts').notNull().default(0),
    /** 総問題数 */
    totalQuestions: integer('total_questions').notNull().default(0),
    /** 正解数 */
    correctAnswers: integer('correct_answers').notNull().default(0),
    /** 正解率（%） */
    accuracyRate: decimal('accuracy_rate', { precision: 5, scale: 2 }).notNull().default('0'),
    /** 総学習時間（秒） */
    totalStudyTimeSeconds: integer('total_study_time_seconds').notNull().default(0),
    /** 最終学習日時 */
    lastStudiedAt: timestamp('last_studied_at', { withTimezone: true }),
    /** 作成日時 */
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
    /** 更新日時 */
    updatedAt: timestamp('updated_at', { withTimezone: true }),
  },
  (table) => [unique('unique_user_category').on(table.userId, table.categoryId)],
);

/**
 * Exam Statistics Table
 * 試験統計テーブル
 * 試験ごとの受験統計を集計
 */
export const examStatistics = pgTable('exam_statistics', {
  /** 統計ID（UUID） */
  id: uuid('id').primaryKey().defaultRandom(),
  /** 試験ID */
  examId: uuid('exam_id')
    .notNull()
    .references(() => exams.id, { onDelete: 'cascade' })
    .unique(),
  /** 総受験回数 */
  totalAttempts: integer('total_attempts').notNull().default(0),
  /** ユニークユーザー数 */
  uniqueUsers: integer('unique_users').notNull().default(0),
  /** 平均点 */
  averageScore: decimal('average_score', { precision: 5, scale: 2 }).notNull().default('0'),
  /** 合格率（%） */
  passRate: decimal('pass_rate', { precision: 5, scale: 2 }).notNull().default('0'),
  /** 平均所要時間（秒） */
  averageTimeSeconds: integer('average_time_seconds').notNull().default(0),
  /** 作成日時 */
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  /** 更新日時 */
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

/**
 * Question Statistics Table
 * 問題統計テーブル
 * 問題ごとの回答統計を集計
 */
export const questionStatistics = pgTable('question_statistics', {
  /** 統計ID（UUID） */
  id: uuid('id').primaryKey().defaultRandom(),
  /** 問題ID */
  questionId: uuid('question_id')
    .notNull()
    .references(() => questions.id, { onDelete: 'cascade' })
    .unique(),
  /** 総回答数 */
  totalAnswers: integer('total_answers').notNull().default(0),
  /** 正解数 */
  correctAnswers: integer('correct_answers').notNull().default(0),
  /** 正解率（%） */
  accuracyRate: decimal('accuracy_rate', { precision: 5, scale: 2 }).notNull().default('0'),
  /** 作成日時 */
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  /** 更新日時 */
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Relations
// ===================================
export const userStatisticsRelations = relations(userStatistics, ({ one }) => ({
  user: one(users, {
    fields: [userStatistics.userId],
    references: [users.id],
  }),
  category: one(examCategories, {
    fields: [userStatistics.categoryId],
    references: [examCategories.id],
  }),
}));

export const examStatisticsRelations = relations(examStatistics, ({ one }) => ({
  exam: one(exams, {
    fields: [examStatistics.examId],
    references: [exams.id],
  }),
}));

export const questionStatisticsRelations = relations(questionStatistics, ({ one }) => ({
  question: one(questions, {
    fields: [questionStatistics.questionId],
    references: [questions.id],
  }),
}));

// ===================================
// Types
// ===================================
export type UserStatistic = typeof userStatistics.$inferSelect;
export type NewUserStatistic = typeof userStatistics.$inferInsert;
export type ExamStatistic = typeof examStatistics.$inferSelect;
export type NewExamStatistic = typeof examStatistics.$inferInsert;
export type QuestionStatistic = typeof questionStatistics.$inferSelect;
export type NewQuestionStatistic = typeof questionStatistics.$inferInsert;
