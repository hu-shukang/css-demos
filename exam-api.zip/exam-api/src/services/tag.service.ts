import { count } from 'drizzle-orm';

import { examTags } from '@/db/schema/index.js';
import { CreateTagRequest } from '@/models/tag.model.js';
import { query } from '@/utils/query-builder.util.js';

export function createTag(input: CreateTagRequest) {
  return query(async (db) => {
    const { name } = input;
    return await db
      .insert(examTags)
      .values({
        name,
      })
      .returning();
  });
}

export function getTotalCount() {
  return query(async (db) => {
    const [{ total }] = await db.select({ total: count() }).from(examTags);
    return total;
  });
}

export function getTagList(limit: number, offset: number) {
  return query(async (db) => {
    return await db.select().from(examTags).limit(limit).offset(offset);
  });
}
