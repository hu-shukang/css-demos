# 試験システム データベース設計

## 要件整理

### 基本機能

1. **試験管理**: 試卷（試験）、試題（問題）、選項（選択肢）、解析（解説）、考試時間（試験時間）、合格線（合格点）の管理
2. **選択問題**: 単一選択と複数選択の両方をサポート
3. **配点**: 問題ごとに配点を設定可能
4. **時間制限**: 期間制限（開始日時〜終了日時）と制限時間（例：60分）の両方をサポート
5. **オンライン答題**: リアルタイムで解答を保存
6. **答題結果の履歴**: 同一試験の複数回受験履歴を記録
7. **折線図**: 同一試験の複数回受験結果を折れ線グラフで表示
8. **錯題集**: 間違えた問題を集約して表示
9. **認証**: AWS Cognito等の外部認証サービスを使用（ユーザーIDのみ保存）

### 追加推奨機能

#### 1. **試験カテゴリー・タグ機能**

- 試験をカテゴリーやタグで分類（例：AWS認定、Java基礎、上級レベルなど）
- ユーザーが興味のある分野の試験を見つけやすくする

#### 2. **問題のランダム出題**

- 問題プールから指定数をランダムに出題
- 毎回異なる問題セットで受験可能（不正防止）

#### 3. **学習進捗管理**

- カテゴリーごとの正答率
- 弱点分野の可視化
- 学習時間の記録

#### 4. **問題の難易度設定**

- 初級・中級・上級などの難易度レベル
- ユーザーのレベルに応じた問題推薦

#### 5. **解説の充実**

- 正解の解説だけでなく、不正解の選択肢についても解説
- 参考リンクやリソースの追加

#### 6. **試験の公開設定**

- 公開/非公開/限定公開（特定ユーザーのみ）
- 下書き状態での保存

#### 7. **統計情報**

- 試験全体の平均点
- 問題ごとの正答率
- 受験者数の統計

#### 8. **復習モード**

- 間違えた問題のみを再度解答
- 正解するまで繰り返し学習

#### 9. **ブックマーク機能**

- 後で見直したい問題をブックマーク
- 重要な問題をマーク

#### 10. **試験のバージョン管理**

- 試験内容の更新履歴
- 過去のバージョンでの受験結果も保持

## データベーステーブル設計

### 1. users（ユーザー）

ユーザーの基本情報を管理。認証はCognitoで行うため、パスワードは保存しない。

| カラム名    | 型           | 制約                   | 説明                                |
| ----------- | ------------ | ---------------------- | ----------------------------------- |
| id          | UUID         | PRIMARY KEY            | ユーザーID（CognitoのサブIDと同期） |
| cognito_sub | VARCHAR(255) | UNIQUE NOT NULL        | Cognito User Sub                    |
| username    | VARCHAR(100) | NOT NULL               | ユーザー名                          |
| email       | VARCHAR(255) | UNIQUE NOT NULL        | メールアドレス                      |
| created_at  | TIMESTAMP    | NOT NULL DEFAULT NOW() | 作成日時                            |
| updated_at  | TIMESTAMP    | NULL                   | 更新日時                            |
| deleted_at  | TIMESTAMP    | NULL                   | 削除日時（論理削除）                |

### 2. exam_categories（試験カテゴリー）

試験を分類するためのカテゴリー。

| カラム名    | 型           | 制約                                  | 説明                       |
| ----------- | ------------ | ------------------------------------- | -------------------------- |
| id          | UUID         | PRIMARY KEY                           | カテゴリーID               |
| parent_id   | UUID         | FOREIGN KEY (exam_categories.id) NULL | 親カテゴリーID（階層構造） |
| name        | VARCHAR(200) | NOT NULL                              | カテゴリー名               |
| description | TEXT         | NULL                                  | カテゴリー説明             |
| sort_order  | INTEGER      | NOT NULL DEFAULT 0                    | 表示順序                   |
| created_at  | TIMESTAMP    | NOT NULL DEFAULT NOW()                | 作成日時                   |
| updated_at  | TIMESTAMP    | NULL                                  | 更新日時                   |
| deleted_at  | TIMESTAMP    | NULL                                  | 削除日時                   |

### 3. exams（試験）

試験の基本情報を管理。

| カラム名             | 型           | 制約                                  | 説明                                     |
| -------------------- | ------------ | ------------------------------------- | ---------------------------------------- |
| id                   | UUID         | PRIMARY KEY                           | 試験ID                                   |
| category_id          | UUID         | FOREIGN KEY (exam_categories.id) NULL | カテゴリーID                             |
| created_by           | UUID         | FOREIGN KEY (users.id) NOT NULL       | 作成者ID                                 |
| title                | VARCHAR(500) | NOT NULL                              | 試験タイトル                             |
| description          | TEXT         | NULL                                  | 試験説明                                 |
| instructions         | TEXT         | NULL                                  | 受験上の注意事項                         |
| status               | VARCHAR(20)  | NOT NULL DEFAULT 'draft'              | ステータス（draft/published/archived）   |
| difficulty_level     | VARCHAR(20)  | NULL                                  | 難易度（beginner/intermediate/advanced） |
| passing_score        | INTEGER      | NOT NULL                              | 合格点                                   |
| total_score          | INTEGER      | NOT NULL                              | 満点                                     |
| time_limit_minutes   | INTEGER      | NULL                                  | 制限時間（分）NULL=無制限                |
| available_from       | TIMESTAMP    | NULL                                  | 受験可能開始日時（NULL=無制限）          |
| available_until      | TIMESTAMP    | NULL                                  | 受験可能終了日時（NULL=無制限）          |
| is_random_order      | BOOLEAN      | NOT NULL DEFAULT FALSE                | 問題をランダム順で出題                   |
| max_attempts         | INTEGER      | NULL                                  | 最大受験回数（NULL=無制限）              |
| show_correct_answers | BOOLEAN      | NOT NULL DEFAULT TRUE                 | 正解を表示するか                         |
| show_explanations    | BOOLEAN      | NOT NULL DEFAULT TRUE                 | 解説を表示するか                         |
| created_at           | TIMESTAMP    | NOT NULL DEFAULT NOW()                | 作成日時                                 |
| updated_at           | TIMESTAMP    | NULL                                  | 更新日時                                 |
| deleted_at           | TIMESTAMP    | NULL                                  | 削除日時                                 |

### 4. exam_tags（試験タグ）

試験に付与するタグ。

| カラム名   | 型           | 制約                   | 説明     |
| ---------- | ------------ | ---------------------- | -------- |
| id         | UUID         | PRIMARY KEY            | タグID   |
| name       | VARCHAR(100) | NOT NULL               | タグ名   |
| created_at | TIMESTAMP    | NOT NULL DEFAULT NOW() | 作成日時 |
| updated_at | TIMESTAMP    | NULL                   | 更新日時 |

### 5. exam_tag_relations（試験タグ関連）

試験とタグの多対多関係。

| カラム名   | 型        | 制約                                | 説明     |
| ---------- | --------- | ----------------------------------- | -------- |
| exam_id    | UUID      | FOREIGN KEY (exams.id) NOT NULL     | 試験ID   |
| tag_id     | UUID      | FOREIGN KEY (exam_tags.id) NOT NULL | タグID   |
| created_at | TIMESTAMP | NOT NULL DEFAULT NOW()              | 作成日時 |

**PRIMARY KEY**: (exam_id, tag_id)

### 6. questions（問題）

試験問題の基本情報。

| カラム名      | 型          | 制約                            | 説明                          |
| ------------- | ----------- | ------------------------------- | ----------------------------- |
| id            | UUID        | PRIMARY KEY                     | 問題ID                        |
| exam_id       | UUID        | FOREIGN KEY (exams.id) NOT NULL | 試験ID                        |
| question_type | VARCHAR(20) | NOT NULL                        | 問題タイプ（single/multiple） |
| question_text | TEXT        | NOT NULL                        | 問題文                        |
| hint          | TEXT        | NULL                            | ヒント                        |
| points        | INTEGER     | NOT NULL DEFAULT 1              | 配点                          |
| sort_order    | INTEGER     | NOT NULL DEFAULT 0              | 表示順序                      |
| created_at    | TIMESTAMP   | NOT NULL DEFAULT NOW()          | 作成日時                      |
| updated_at    | TIMESTAMP   | NULL                            | 更新日時                      |
| deleted_at    | TIMESTAMP   | NULL                            | 削除日時                      |

### 7. choices（選択肢）

問題の選択肢。

| カラム名    | 型        | 制約                                | 説明           |
| ----------- | --------- | ----------------------------------- | -------------- |
| id          | UUID      | PRIMARY KEY                         | 選択肢ID       |
| question_id | UUID      | FOREIGN KEY (questions.id) NOT NULL | 問題ID         |
| choice_text | TEXT      | NOT NULL                            | 選択肢テキスト |
| is_correct  | BOOLEAN   | NOT NULL DEFAULT FALSE              | 正解フラグ     |
| sort_order  | INTEGER   | NOT NULL DEFAULT 0                  | 表示順序       |
| created_at  | TIMESTAMP | NOT NULL DEFAULT NOW()              | 作成日時       |
| updated_at  | TIMESTAMP | NULL                                | 更新日時       |
| deleted_at  | TIMESTAMP | NULL                                | 削除日時       |

### 8. explanations（解説）

問題の解説。

| カラム名         | 型           | 制約                                | 説明                            |
| ---------------- | ------------ | ----------------------------------- | ------------------------------- |
| id               | UUID         | PRIMARY KEY                         | 解説ID                          |
| question_id      | UUID         | FOREIGN KEY (questions.id) NOT NULL | 問題ID                          |
| choice_id        | UUID         | FOREIGN KEY (choices.id) NULL       | 選択肢ID（NULL=問題全体の解説） |
| explanation_text | TEXT         | NOT NULL                            | 解説テキスト                    |
| reference_url    | VARCHAR(500) | NULL                                | 参考URL                         |
| created_at       | TIMESTAMP    | NOT NULL DEFAULT NOW()              | 作成日時                        |
| updated_at       | TIMESTAMP    | NULL                                | 更新日時                        |

### 9. exam_attempts（受験記録）

ユーザーの受験記録。

| カラム名           | 型          | 制約                            | 説明                                          |
| ------------------ | ----------- | ------------------------------- | --------------------------------------------- |
| id                 | UUID        | PRIMARY KEY                     | 受験記録ID                                    |
| exam_id            | UUID        | FOREIGN KEY (exams.id) NOT NULL | 試験ID                                        |
| user_id            | UUID        | FOREIGN KEY (users.id) NOT NULL | ユーザーID                                    |
| attempt_number     | INTEGER     | NOT NULL                        | 受験回数（1回目、2回目...）                   |
| status             | VARCHAR(20) | NOT NULL DEFAULT 'in_progress'  | ステータス（in_progress/completed/abandoned） |
| score              | INTEGER     | NULL                            | 得点（完了時に設定）                          |
| total_score        | INTEGER     | NULL                            | 満点（完了時に設定）                          |
| is_passed          | BOOLEAN     | NULL                            | 合格フラグ（完了時に設定）                    |
| started_at         | TIMESTAMP   | NOT NULL DEFAULT NOW()          | 開始日時                                      |
| completed_at       | TIMESTAMP   | NULL                            | 完了日時                                      |
| time_spent_seconds | INTEGER     | NULL                            | 所要時間（秒）                                |
| created_at         | TIMESTAMP   | NOT NULL DEFAULT NOW()          | 作成日時                                      |
| updated_at         | TIMESTAMP   | NULL                            | 更新日時                                      |

**INDEX**: (user_id, exam_id, attempt_number)

### 10. user_answers（ユーザー解答）

ユーザーの各問題への解答。

| カラム名      | 型        | 制約                                    | 説明             |
| ------------- | --------- | --------------------------------------- | ---------------- |
| id            | UUID      | PRIMARY KEY                             | 解答ID           |
| attempt_id    | UUID      | FOREIGN KEY (exam_attempts.id) NOT NULL | 受験記録ID       |
| question_id   | UUID      | FOREIGN KEY (questions.id) NOT NULL     | 問題ID           |
| choice_id     | UUID      | FOREIGN KEY (choices.id) NOT NULL       | 選択した選択肢ID |
| is_correct    | BOOLEAN   | NOT NULL                                | 正解フラグ       |
| points_earned | INTEGER   | NOT NULL DEFAULT 0                      | 獲得点数         |
| answered_at   | TIMESTAMP | NOT NULL DEFAULT NOW()                  | 解答日時         |
| created_at    | TIMESTAMP | NOT NULL DEFAULT NOW()                  | 作成日時         |
| updated_at    | TIMESTAMP | NULL                                    | 更新日時         |

**INDEX**: (attempt_id, question_id)

### 11. wrong_questions（錯題集）

ユーザーが間違えた問題の集約。

| カラム名      | 型        | 制約                                | 説明               |
| ------------- | --------- | ----------------------------------- | ------------------ |
| id            | UUID      | PRIMARY KEY                         | 錯題ID             |
| user_id       | UUID      | FOREIGN KEY (users.id) NOT NULL     | ユーザーID         |
| question_id   | UUID      | FOREIGN KEY (questions.id) NOT NULL | 問題ID             |
| wrong_count   | INTEGER   | NOT NULL DEFAULT 1                  | 間違えた回数       |
| last_wrong_at | TIMESTAMP | NOT NULL DEFAULT NOW()              | 最後に間違えた日時 |
| is_mastered   | BOOLEAN   | NOT NULL DEFAULT FALSE              | 克服済みフラグ     |
| mastered_at   | TIMESTAMP | NULL                                | 克服日時           |
| created_at    | TIMESTAMP | NOT NULL DEFAULT NOW()              | 作成日時           |
| updated_at    | TIMESTAMP | NULL                                | 更新日時           |

**UNIQUE制約**: (user_id, question_id)

### 12. bookmarks（ブックマーク）

ユーザーがブックマークした問題。

| カラム名    | 型        | 制約                                | 説明           |
| ----------- | --------- | ----------------------------------- | -------------- |
| id          | UUID      | PRIMARY KEY                         | ブックマークID |
| user_id     | UUID      | FOREIGN KEY (users.id) NOT NULL     | ユーザーID     |
| question_id | UUID      | FOREIGN KEY (questions.id) NOT NULL | 問題ID         |
| note        | TEXT      | NULL                                | メモ           |
| created_at  | TIMESTAMP | NOT NULL DEFAULT NOW()              | 作成日時       |
| updated_at  | TIMESTAMP | NULL                                | 更新日時       |

**UNIQUE制約**: (user_id, question_id)

### 13. user_statistics（ユーザー統計）

ユーザーの学習統計情報（集計テーブル）。

| カラム名                 | 型           | 制約                                  | 説明                      |
| ------------------------ | ------------ | ------------------------------------- | ------------------------- |
| id                       | UUID         | PRIMARY KEY                           | 統計ID                    |
| user_id                  | UUID         | FOREIGN KEY (users.id) NOT NULL       | ユーザーID                |
| category_id              | UUID         | FOREIGN KEY (exam_categories.id) NULL | カテゴリーID（NULL=全体） |
| total_attempts           | INTEGER      | NOT NULL DEFAULT 0                    | 総受験回数                |
| total_questions          | INTEGER      | NOT NULL DEFAULT 0                    | 総問題数                  |
| correct_answers          | INTEGER      | NOT NULL DEFAULT 0                    | 正解数                    |
| accuracy_rate            | DECIMAL(5,2) | NOT NULL DEFAULT 0                    | 正答率（%）               |
| total_study_time_seconds | INTEGER      | NOT NULL DEFAULT 0                    | 総学習時間（秒）          |
| last_studied_at          | TIMESTAMP    | NULL                                  | 最終学習日時              |
| created_at               | TIMESTAMP    | NOT NULL DEFAULT NOW()                | 作成日時                  |
| updated_at               | TIMESTAMP    | NULL                                  | 更新日時                  |

**UNIQUE制約**: (user_id, category_id)

### 14. exam_statistics（試験統計）

試験全体の統計情報（集計テーブル）。

| カラム名             | 型           | 制約                            | 説明               |
| -------------------- | ------------ | ------------------------------- | ------------------ |
| id                   | UUID         | PRIMARY KEY                     | 統計ID             |
| exam_id              | UUID         | FOREIGN KEY (exams.id) NOT NULL | 試験ID             |
| total_attempts       | INTEGER      | NOT NULL DEFAULT 0              | 総受験回数         |
| unique_users         | INTEGER      | NOT NULL DEFAULT 0              | ユニークユーザー数 |
| average_score        | DECIMAL(5,2) | NOT NULL DEFAULT 0              | 平均点             |
| pass_rate            | DECIMAL(5,2) | NOT NULL DEFAULT 0              | 合格率（%）        |
| average_time_seconds | INTEGER      | NOT NULL DEFAULT 0              | 平均所要時間（秒） |
| created_at           | TIMESTAMP    | NOT NULL DEFAULT NOW()          | 作成日時           |
| updated_at           | TIMESTAMP    | NULL                            | 更新日時           |

**UNIQUE制約**: (exam_id)

### 15. question_statistics（問題統計）

問題ごとの統計情報（集計テーブル）。

| カラム名        | 型           | 制約                                | 説明        |
| --------------- | ------------ | ----------------------------------- | ----------- |
| id              | UUID         | PRIMARY KEY                         | 統計ID      |
| question_id     | UUID         | FOREIGN KEY (questions.id) NOT NULL | 問題ID      |
| total_answers   | INTEGER      | NOT NULL DEFAULT 0                  | 総解答数    |
| correct_answers | INTEGER      | NOT NULL DEFAULT 0                  | 正解数      |
| accuracy_rate   | DECIMAL(5,2) | NOT NULL DEFAULT 0                  | 正答率（%） |
| created_at      | TIMESTAMP    | NOT NULL DEFAULT NOW()              | 作成日時    |
| updated_at      | TIMESTAMP    | NULL                                | 更新日時    |

**UNIQUE制約**: (question_id)

## ER図（Mermaid）

```mermaid
erDiagram
    users ||--o{ exam_attempts : "受験する"
    users ||--o{ wrong_questions : "間違える"
    users ||--o{ bookmarks : "ブックマークする"
    users ||--o{ user_statistics : "統計を持つ"
    users ||--o{ exams : "作成する"

    exam_categories ||--o{ exam_categories : "親子関係"
    exam_categories ||--o{ exams : "分類される"
    exam_categories ||--o{ user_statistics : "統計を持つ"

    exams ||--o{ exam_tag_relations : "タグ付けされる"
    exams ||--o{ questions : "問題を持つ"
    exams ||--o{ exam_attempts : "受験される"
    exams ||--o{ exam_statistics : "統計を持つ"

    exam_tags ||--o{ exam_tag_relations : "試験に付与される"

    questions ||--o{ choices : "選択肢を持つ"
    questions ||--o{ explanations : "解説を持つ"
    questions ||--o{ user_answers : "解答される"
    questions ||--o{ wrong_questions : "間違えられる"
    questions ||--o{ bookmarks : "ブックマークされる"
    questions ||--o{ question_statistics : "統計を持つ"

    choices ||--o{ explanations : "解説を持つ"
    choices ||--o{ user_answers : "選択される"

    exam_attempts ||--o{ user_answers : "解答を持つ"

    users {
        UUID id PK
        VARCHAR cognito_sub UK
        VARCHAR username
        VARCHAR email UK
        VARCHAR preferred_language
        TIMESTAMP created_at
        TIMESTAMP updated_at
        TIMESTAMP deleted_at
    }

    exam_categories {
        UUID id PK
        UUID parent_id FK
        VARCHAR name
        TEXT description
        INTEGER sort_order
        TIMESTAMP created_at
        TIMESTAMP updated_at
        TIMESTAMP deleted_at
    }

    exams {
        UUID id PK
        UUID category_id FK
        UUID created_by FK
        VARCHAR title
        TEXT description
        TEXT instructions
        VARCHAR status
        VARCHAR difficulty_level
        INTEGER passing_score
        INTEGER total_score
        INTEGER time_limit_minutes
        TIMESTAMP available_from
        TIMESTAMP available_until
        BOOLEAN is_random_order
        INTEGER max_attempts
        BOOLEAN show_correct_answers
        BOOLEAN show_explanations
        TIMESTAMP created_at
        TIMESTAMP updated_at
        TIMESTAMP deleted_at
    }

    exam_tags {
        UUID id PK
        VARCHAR name
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    exam_tag_relations {
        UUID exam_id FK
        UUID tag_id FK
        TIMESTAMP created_at
    }

    questions {
        UUID id PK
        UUID exam_id FK
        VARCHAR question_type
        TEXT question_text
        TEXT hint
        INTEGER points
        INTEGER sort_order
        TIMESTAMP created_at
        TIMESTAMP updated_at
        TIMESTAMP deleted_at
    }

    choices {
        UUID id PK
        UUID question_id FK
        TEXT choice_text
        BOOLEAN is_correct
        INTEGER sort_order
        TIMESTAMP created_at
        TIMESTAMP updated_at
        TIMESTAMP deleted_at
    }

    explanations {
        UUID id PK
        UUID question_id FK
        UUID choice_id FK
        TEXT explanation_text
        VARCHAR reference_url
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    exam_attempts {
        UUID id PK
        UUID exam_id FK
        UUID user_id FK
        INTEGER attempt_number
        VARCHAR status
        INTEGER score
        INTEGER total_score
        BOOLEAN is_passed
        TIMESTAMP started_at
        TIMESTAMP completed_at
        INTEGER time_spent_seconds
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    user_answers {
        UUID id PK
        UUID attempt_id FK
        UUID question_id FK
        UUID choice_id FK
        BOOLEAN is_correct
        INTEGER points_earned
        TIMESTAMP answered_at
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    wrong_questions {
        UUID id PK
        UUID user_id FK
        UUID question_id FK
        INTEGER wrong_count
        TIMESTAMP last_wrong_at
        BOOLEAN is_mastered
        TIMESTAMP mastered_at
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    bookmarks {
        UUID id PK
        UUID user_id FK
        UUID question_id FK
        TEXT note
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    user_statistics {
        UUID id PK
        UUID user_id FK
        UUID category_id FK
        INTEGER total_attempts
        INTEGER total_questions
        INTEGER correct_answers
        DECIMAL accuracy_rate
        INTEGER total_study_time_seconds
        TIMESTAMP last_studied_at
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    exam_statistics {
        UUID id PK
        UUID exam_id FK
        INTEGER total_attempts
        INTEGER unique_users
        DECIMAL average_score
        DECIMAL pass_rate
        INTEGER average_time_seconds
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }

    question_statistics {
        UUID id PK
        UUID question_id FK
        INTEGER total_answers
        INTEGER correct_answers
        DECIMAL accuracy_rate
        TIMESTAMP created_at
        TIMESTAMP updated_at
    }
```

## 主要なインデックス設計

### パフォーマンス最適化のためのインデックス

```sql
-- users
CREATE INDEX idx_users_cognito_sub ON users(cognito_sub);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_deleted_at ON users(deleted_at);

-- exam_categories
CREATE INDEX idx_exam_categories_parent_id ON exam_categories(parent_id);
CREATE INDEX idx_exam_categories_deleted_at ON exam_categories(deleted_at);

-- exams
CREATE INDEX idx_exams_category_id ON exams(category_id);
CREATE INDEX idx_exams_created_by ON exams(created_by);
CREATE INDEX idx_exams_status ON exams(status);
CREATE INDEX idx_exams_difficulty_level ON exams(difficulty_level);
CREATE INDEX idx_exams_available_from_until ON exams(available_from, available_until);
CREATE INDEX idx_exams_deleted_at ON exams(deleted_at);

-- exam_tag_relations
CREATE INDEX idx_exam_tag_relations_exam_id ON exam_tag_relations(exam_id);
CREATE INDEX idx_exam_tag_relations_tag_id ON exam_tag_relations(tag_id);

-- questions
CREATE INDEX idx_questions_exam_id ON questions(exam_id);
CREATE INDEX idx_questions_sort_order ON questions(sort_order);
CREATE INDEX idx_questions_deleted_at ON questions(deleted_at);

-- choices
CREATE INDEX idx_choices_question_id ON choices(question_id);
CREATE INDEX idx_choices_is_correct ON choices(is_correct);
CREATE INDEX idx_choices_deleted_at ON choices(deleted_at);

-- explanations
CREATE INDEX idx_explanations_question_id ON explanations(question_id);
CREATE INDEX idx_explanations_choice_id ON explanations(choice_id);

-- exam_attempts
CREATE INDEX idx_exam_attempts_exam_id ON exam_attempts(exam_id);
CREATE INDEX idx_exam_attempts_user_id ON exam_attempts(user_id);
CREATE INDEX idx_exam_attempts_user_exam ON exam_attempts(user_id, exam_id, attempt_number);
CREATE INDEX idx_exam_attempts_status ON exam_attempts(status);
CREATE INDEX idx_exam_attempts_started_at ON exam_attempts(started_at);
CREATE INDEX idx_exam_attempts_completed_at ON exam_attempts(completed_at);

-- user_answers
CREATE INDEX idx_user_answers_attempt_id ON user_answers(attempt_id);
CREATE INDEX idx_user_answers_question_id ON user_answers(question_id);
CREATE INDEX idx_user_answers_attempt_question ON user_answers(attempt_id, question_id);
CREATE INDEX idx_user_answers_is_correct ON user_answers(is_correct);

-- wrong_questions
CREATE INDEX idx_wrong_questions_user_id ON wrong_questions(user_id);
CREATE INDEX idx_wrong_questions_question_id ON wrong_questions(question_id);
CREATE INDEX idx_wrong_questions_is_mastered ON wrong_questions(is_mastered);
CREATE INDEX idx_wrong_questions_last_wrong_at ON wrong_questions(last_wrong_at);

-- bookmarks
CREATE INDEX idx_bookmarks_user_id ON bookmarks(user_id);
CREATE INDEX idx_bookmarks_question_id ON bookmarks(question_id);

-- user_statistics
CREATE INDEX idx_user_statistics_user_id ON user_statistics(user_id);
CREATE INDEX idx_user_statistics_category_id ON user_statistics(category_id);
CREATE INDEX idx_user_statistics_user_category ON user_statistics(user_id, category_id);

-- exam_statistics
CREATE INDEX idx_exam_statistics_exam_id ON exam_statistics(exam_id);

-- question_statistics
CREATE INDEX idx_question_statistics_question_id ON question_statistics(question_id);
```

## 設計のポイント

### 1. 論理削除

- 主要テーブルに`deleted_at`カラムを追加
- 物理削除せず、削除フラグで管理
- 履歴データの保持と復元が可能

### 2. 時間制限の柔軟性

- `available_from`/`available_until`: 受験可能期間
- `time_limit_minutes`: 1回の受験の制限時間
- 両方NULLで無制限、片方だけ設定も可能

### 3. 統計情報の集計

- `user_statistics`: ユーザーごとの学習統計
- `exam_statistics`: 試験ごとの統計
- `question_statistics`: 問題ごとの統計
- 集計テーブルで頻繁なクエリのパフォーマンスを向上

### 4. 錯題集の自動管理

- `wrong_questions`テーブルで間違えた問題を自動記録
- `wrong_count`で間違えた回数をカウント
- `is_mastered`で克服済みかを管理

### 5. 受験履歴の完全記録

- `exam_attempts`で受験ごとの記録
- `user_answers`で各問題への解答を記録
- 折れ線グラフ用のデータが完全に保存される

### 6. 柔軟な試験設定

- ランダム出題の有無
- 正解・解説の表示制御
- 最大受験回数の制限
- 難易度レベルの設定

### 7. カテゴリーの階層構造

- `parent_id`で親子関係を表現
- 無制限の階層構造が可能
- カテゴリーごとの統計も取得可能

## 次のステップ

1. **Drizzle ORMスキーマ定義の作成**
2. **Zodバリデーションスキーマの設計**
3. **APIエンドポイント設計**
4. **マイグレーションファイルの作成**
