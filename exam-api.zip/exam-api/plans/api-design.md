# 試験システム APIエンドポイント設計

## 概要

このドキュメントでは、試験システムのRESTful APIエンドポイントを定義します。
既存のプロジェクト構造（Fastify + Drizzle ORM）に従い、ディレクトリベースルーティングを使用します。

## 認証・認可

### 認証方式

- AWS Cognito JWTトークンを使用
- `Authorization: Bearer <token>`ヘッダーで認証
- Cognitoのサブ（sub）からユーザーIDを取得

### 権限レベル

- **一般ユーザー**: 試験の受験、自分の履歴閲覧
- **試験作成者**: 自分が作成した試験の管理
- **管理者**: 全ての試験・ユーザーの管理

## APIエンドポイント一覧

### 1. ユーザー管理 (`/users`)

#### 1.1 現在のユーザー情報取得

```
GET /users/me
```

**説明**: ログイン中のユーザー情報を取得

**レスポンス**:

```json
{
  "id": "uuid",
  "username": "string",
  "email": "string",
  "createdAt": "2024-01-01T00:00:00Z",
  "updatedAt": "2024-01-01T00:00:00Z"
}
```

#### 1.2 ユーザー情報更新

```
PATCH /users/me
```

**説明**: ログイン中のユーザー情報を更新

**リクエストボディ**:

```json
{
  "username": "string"
}
```

#### 1.3 ユーザー統計取得

```
GET /users/me/statistics
```

**説明**: ログイン中のユーザーの学習統計を取得

**クエリパラメータ**:

- `categoryId` (optional): カテゴリーIDでフィルタ

**レスポンス**:

```json
{
  "overall": {
    "totalAttempts": 10,
    "totalQuestions": 100,
    "correctAnswers": 80,
    "accuracyRate": 80.0,
    "totalStudyTimeSeconds": 3600,
    "lastStudiedAt": "2024-01-01T00:00:00Z"
  },
  "byCategory": [
    {
      "categoryId": "uuid",
      "categoryName": "AWS認定",
      "totalAttempts": 5,
      "correctAnswers": 40,
      "accuracyRate": 80.0
    }
  ]
}
```

### 2. カテゴリー管理 (`/categories`)

#### 2.1 カテゴリー一覧取得

```
GET /categories
```

**説明**: カテゴリーの階層構造を取得

**レスポンス**:

```json
[
  {
    "id": "uuid",
    "parentId": null,
    "name": "AWS認定",
    "description": "AWS認定試験のカテゴリー",
    "sortOrder": 0,
    "children": [
      {
        "id": "uuid",
        "parentId": "uuid",
        "name": "ソリューションアーキテクト",
        "description": "SAA試験",
        "sortOrder": 0,
        "children": []
      }
    ]
  }
]
```

#### 2.2 カテゴリー作成（管理者のみ）

```
POST /categories
```

**リクエストボディ**:

```json
{
  "parentId": "uuid",
  "name": "AWS認定",
  "description": "AWS認定試験のカテゴリー",
  "sortOrder": 0
}
```

#### 2.3 カテゴリー更新（管理者のみ）

```
PATCH /categories/:id
```

#### 2.4 カテゴリー削除（管理者のみ）

```
DELETE /categories/:id
```

### 3. タグ管理 (`/tags`)

#### 3.1 タグ一覧取得

```
GET /tags
```

**レスポンス**:

```json
[
  {
    "id": "uuid",
    "name": "初級"
  }
]
```

#### 3.2 タグ作成（管理者のみ）

```
POST /tags
```

#### 3.3 タグ更新（管理者のみ）

```
PATCH /tags/:id
```

#### 3.4 タグ削除（管理者のみ）

```
DELETE /tags/:id
```

### 4. 試験管理 (`/exams`)

#### 4.1 試験一覧取得

```
GET /exams
```

**説明**: 公開されている試験の一覧を取得

**クエリパラメータ**:

- `categoryId` (optional): カテゴリーIDでフィルタ
- `tagId` (optional): タグIDでフィルタ
- `difficulty` (optional): 難易度でフィルタ（beginner/intermediate/advanced）
- `page` (optional): ページ番号（デフォルト: 1）
- `limit` (optional): 1ページあたりの件数（デフォルト: 20）
- `sortBy` (optional): ソート項目（createdAt/title/popularity）
- `order` (optional): ソート順（asc/desc）

**レスポンス**:

```json
{
  "data": [
    {
      "id": "uuid",
      "title": "AWS SAA模擬試験",
      "description": "AWS認定ソリューションアーキテクト アソシエイト模擬試験",
      "categoryId": "uuid",
      "categoryName": "AWS認定",
      "difficulty": "intermediate",
      "passingScore": 720,
      "totalScore": 1000,
      "timeLimitMinutes": 130,
      "availableFrom": "2024-01-01T00:00:00Z",
      "availableUntil": null,
      "questionCount": 65,
      "tags": ["初級", "AWS"],
      "statistics": {
        "totalAttempts": 100,
        "averageScore": 750,
        "passRate": 75.0
      },
      "createdAt": "2024-01-01T00:00:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 100,
    "totalPages": 5
  }
}
```

#### 4.2 試験詳細取得

```
GET /exams/:id
```

**レスポンス**:

```json
{
  "id": "uuid",
  "title": "AWS SAA模擬試験",
  "description": "AWS認定ソリューションアーキテクト アソシエイト模擬試験",
  "instructions": "試験時間は130分です。65問の問題に解答してください。",
  "categoryId": "uuid",
  "categoryName": "AWS認定",
  "difficulty": "intermediate",
  "passingScore": 720,
  "totalScore": 1000,
  "timeLimitMinutes": 130,
  "availableFrom": "2024-01-01T00:00:00Z",
  "availableUntil": null,
  "isRandomOrder": false,
  "maxAttempts": null,
  "showCorrectAnswers": true,
  "showExplanations": true,
  "questionCount": 65,
  "tags": ["初級", "AWS"],
  "statistics": {
    "totalAttempts": 100,
    "uniqueUsers": 50,
    "averageScore": 750,
    "passRate": 75.0,
    "averageTimeSeconds": 7200
  },
  "userAttempts": 2,
  "userBestScore": 800,
  "createdBy": {
    "id": "uuid",
    "username": "admin"
  },
  "createdAt": "2024-01-01T00:00:00Z",
  "updatedAt": "2024-01-01T00:00:00Z"
}
```

#### 4.3 試験作成

```
POST /exams
```

**リクエストボディ**:

```json
{
  "categoryId": "uuid",
  "title": "AWS SAA模擬試験",
  "description": "AWS認定ソリューションアーキテクト アソシエイト模擬試験",
  "instructions": "試験時間は130分です。",
  "difficulty": "intermediate",
  "passingScore": 720,
  "totalScore": 1000,
  "timeLimitMinutes": 130,
  "availableFrom": "2024-01-01T00:00:00Z",
  "availableUntil": null,
  "isRandomOrder": false,
  "maxAttempts": null,
  "showCorrectAnswers": true,
  "showExplanations": true,
  "status": "draft",
  "tagIds": ["uuid1", "uuid2"]
}
```

#### 4.4 試験更新

```
PATCH /exams/:id
```

**説明**: 自分が作成した試験のみ更新可能

#### 4.5 試験削除

```
DELETE /exams/:id
```

**説明**: 自分が作成した試験のみ削除可能（論理削除）

#### 4.6 試験の公開/非公開切り替え

```
PATCH /exams/:id/status
```

**リクエストボディ**:

```json
{
  "status": "published"
}
```

#### 4.7 自分が作成した試験一覧

```
GET /exams/my-exams
```

**説明**: ログイン中のユーザーが作成した試験の一覧

### 5. 問題管理 (`/exams/:examId/questions`)

#### 5.1 試験の問題一覧取得

```
GET /exams/:examId/questions
```

**レスポンス**:

```json
[
  {
    "id": "uuid",
    "questionType": "single",
    "questionText": "AWSのS3とは何ですか？",
    "hint": "オブジェクトストレージサービスです",
    "points": 10,
    "sortOrder": 1,
    "choices": [
      {
        "id": "uuid",
        "choiceText": "オブジェクトストレージサービス",
        "sortOrder": 1
      },
      {
        "id": "uuid",
        "choiceText": "リレーショナルデータベース",
        "sortOrder": 2
      }
    ]
  }
]
```

#### 5.2 問題作成

```
POST /exams/:examId/questions
```

**リクエストボディ**:

```json
{
  "questionType": "single",
  "questionText": "AWSのS3とは何ですか？",
  "hint": "オブジェクトストレージサービスです",
  "points": 10,
  "sortOrder": 1,
  "choices": [
    {
      "choiceText": "オブジェクトストレージサービス",
      "isCorrect": true,
      "sortOrder": 1
    }
  ],
  "explanations": [
    {
      "choiceId": null,
      "explanationText": "S3はSimple Storage Serviceの略です。",
      "referenceUrl": "https://aws.amazon.com/s3/"
    }
  ]
}
```

#### 5.3 問題更新

```
PATCH /exams/:examId/questions/:questionId
```

#### 5.4 問題削除

```
DELETE /exams/:examId/questions/:questionId
```

#### 5.5 問題の並び替え

```
PATCH /exams/:examId/questions/reorder
```

**リクエストボディ**:

```json
{
  "questionOrders": [
    { "questionId": "uuid1", "sortOrder": 1 },
    { "questionId": "uuid2", "sortOrder": 2 }
  ]
}
```

### 6. 受験管理 (`/attempts`)

#### 6.1 受験開始

```
POST /exams/:examId/attempts
```

**説明**: 新しい受験セッションを開始

**レスポンス**:

```json
{
  "attemptId": "uuid",
  "examId": "uuid",
  "examTitle": "AWS SAA模擬試験",
  "attemptNumber": 1,
  "timeLimitMinutes": 130,
  "startedAt": "2024-01-01T10:00:00Z",
  "expiresAt": "2024-01-01T12:10:00Z",
  "questions": [
    {
      "id": "uuid",
      "questionType": "single",
      "questionText": "AWSのS3とは何ですか？",
      "hint": "オブジェクトストレージサービスです",
      "points": 10,
      "choices": [
        {
          "id": "uuid",
          "choiceText": "オブジェクトストレージサービス"
        },
        {
          "id": "uuid",
          "choiceText": "リレーショナルデータベース"
        }
      ]
    }
  ]
}
```

#### 6.2 解答の保存

```
POST /attempts/:attemptId/answers
```

**説明**: 問題への解答を保存（複数回呼び出し可能、上書き保存）

**リクエストボディ**:

```json
{
  "questionId": "uuid",
  "choiceIds": ["uuid"]
}
```

**レスポンス**:

```json
{
  "success": true,
  "answeredAt": "2024-01-01T10:05:00Z"
}
```

#### 6.3 受験完了

```
POST /attempts/:attemptId/complete
```

**説明**: 受験を完了し、採点を実行

**レスポンス**:

```json
{
  "attemptId": "uuid",
  "examId": "uuid",
  "examTitle": "AWS SAA模擬試験",
  "score": 800,
  "totalScore": 1000,
  "isPassed": true,
  "passingScore": 720,
  "correctCount": 52,
  "totalQuestions": 65,
  "accuracyRate": 80.0,
  "timeSpentSeconds": 7200,
  "completedAt": "2024-01-01T12:00:00Z",
  "results": [
    {
      "questionId": "uuid",
      "questionText": "AWSのS3とは何ですか？",
      "userChoiceIds": ["uuid"],
      "correctChoiceIds": ["uuid"],
      "isCorrect": true,
      "pointsEarned": 10,
      "explanation": {
        "explanationText": "S3はSimple Storage Serviceの略です。",
        "referenceUrl": "https://aws.amazon.com/s3/"
      }
    }
  ]
}
```

#### 6.4 受験履歴一覧

```
GET /users/me/attempts
```

**クエリパラメータ**:

- `examId` (optional): 試験IDでフィルタ
- `status` (optional): ステータスでフィルタ
- `page` (optional): ページ番号
- `limit` (optional): 1ページあたりの件数

**レスポンス**:

```json
{
  "data": [
    {
      "attemptId": "uuid",
      "examId": "uuid",
      "examTitle": "AWS SAA模擬試験",
      "attemptNumber": 1,
      "status": "completed",
      "score": 800,
      "totalScore": 1000,
      "isPassed": true,
      "startedAt": "2024-01-01T10:00:00Z",
      "completedAt": "2024-01-01T12:00:00Z",
      "timeSpentSeconds": 7200
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 10,
    "totalPages": 1
  }
}
```

#### 6.5 受験結果詳細

```
GET /attempts/:attemptId
```

**説明**: 特定の受験結果の詳細を取得

**レスポンス**: 6.3と同じ形式

#### 6.6 試験ごとの受験履歴（折れ線グラフ用）

```
GET /exams/:examId/my-attempts
```

**説明**: 特定の試験の自分の受験履歴を取得（折れ線グラフ表示用）

**レスポンス**:

```json
{
  "examId": "uuid",
  "examTitle": "AWS SAA模擬試験",
  "attempts": [
    {
      "attemptNumber": 1,
      "score": 700,
      "totalScore": 1000,
      "isPassed": false,
      "accuracyRate": 70.0,
      "completedAt": "2024-01-01T12:00:00Z"
    },
    {
      "attemptNumber": 2,
      "score": 800,
      "totalScore": 1000,
      "isPassed": true,
      "accuracyRate": 80.0,
      "completedAt": "2024-01-05T12:00:00Z"
    }
  ],
  "bestScore": 800,
  "averageScore": 750,
  "totalAttempts": 2
}
```

### 7. 錯題集 (`/wrong-questions`)

#### 7.1 錯題集一覧取得

```
GET /users/me/wrong-questions
```

**クエリパラメータ**:

- `examId` (optional): 試験IDでフィルタ
- `categoryId` (optional): カテゴリーIDでフィルタ
- `isMastered` (optional): 克服済みフラグでフィルタ
- `sortBy` (optional): ソート項目（wrongCount/lastWrongAt）
- `order` (optional): ソート順（asc/desc）

**レスポンス**:

```json
{
  "data": [
    {
      "id": "uuid",
      "questionId": "uuid",
      "examId": "uuid",
      "examTitle": "AWS SAA模擬試験",
      "questionText": "AWSのS3とは何ですか？",
      "wrongCount": 3,
      "lastWrongAt": "2024-01-05T12:00:00Z",
      "isMastered": false,
      "choices": [
        {
          "id": "uuid",
          "choiceText": "オブジェクトストレージサービス",
          "isCorrect": true
        }
      ]
    }
  ],
  "summary": {
    "totalWrongQuestions": 10,
    "masteredCount": 3,
    "notMasteredCount": 7
  }
}
```

#### 7.2 錯題を克服済みにする

```
PATCH /users/me/wrong-questions/:questionId/master
```

**説明**: 特定の問題を克服済みとしてマーク

**レスポンス**:

```json
{
  "success": true,
  "masteredAt": "2024-01-10T12:00:00Z"
}
```

#### 7.3 錯題の復習モード開始

```
POST /users/me/wrong-questions/review
```

**説明**: 錯題のみを集めた復習セッションを開始

**クエリパラメータ**:

- `examId` (optional): 特定の試験の錯題のみ
- `limit` (optional): 問題数の上限

**レスポンス**: 6.1と同じ形式（attemptIdが返される）

### 8. ブックマーク (`/bookmarks`)

#### 8.1 ブックマーク一覧取得

```
GET /users/me/bookmarks
```

**クエリパラメータ**:

- `examId` (optional): 試験IDでフィルタ

**レスポンス**:

```json
[
  {
    "id": "uuid",
    "questionId": "uuid",
    "examId": "uuid",
    "examTitle": "AWS SAA模擬試験",
    "questionText": "AWSのS3とは何ですか？",
    "note": "後で復習する",
    "createdAt": "2024-01-01T12:00:00Z"
  }
]
```

#### 8.2 ブックマーク追加

```
POST /users/me/bookmarks
```

**リクエストボディ**:

```json
{
  "questionId": "uuid",
  "note": "後で復習する"
}
```

#### 8.3 ブックマーク更新

```
PATCH /users/me/bookmarks/:questionId
```

**リクエストボディ**:

```json
{
  "note": "重要な問題"
}
```

#### 8.4 ブックマーク削除

```
DELETE /users/me/bookmarks/:questionId
```

### 9. 統計情報 (`/statistics`)

#### 9.1 試験統計取得

```
GET /exams/:examId/statistics
```

**説明**: 試験全体の統計情報を取得

**レスポンス**:

```json
{
  "examId": "uuid",
  "totalAttempts": 100,
  "uniqueUsers": 50,
  "averageScore": 750,
  "passRate": 75.0,
  "averageTimeSeconds": 7200,
  "scoreDistribution": [
    { "range": "0-200", "count": 5 },
    { "range": "201-400", "count": 10 },
    { "range": "401-600", "count": 15 },
    { "range": "601-800", "count": 40 },
    { "range": "801-1000", "count": 30 }
  ],
  "questionStatistics": [
    {
      "questionId": "uuid",
      "questionText": "AWSのS3とは何ですか？",
      "totalAnswers": 100,
      "correctAnswers": 80,
      "accuracyRate": 80.0
    }
  ]
}
```

#### 9.2 問題統計取得

```
GET /questions/:questionId/statistics
```

**説明**: 特定の問題の統計情報を取得

**レスポンス**:

```json
{
  "questionId": "uuid",
  "questionText": "AWSのS3とは何ですか？",
  "totalAnswers": 100,
  "correctAnswers": 80,
  "accuracyRate": 80.0,
  "choiceDistribution": [
    {
      "choiceId": "uuid",
      "choiceText": "オブジェクトストレージサービス",
      "isCorrect": true,
      "selectedCount": 80,
      "percentage": 80.0
    },
    {
      "choiceId": "uuid",
      "choiceText": "リレーショナルデータベース",
      "isCorrect": false,
      "selectedCount": 20,
      "percentage": 20.0
    }
  ]
}
```

## ファイル構造（Fastifyディレクトリベースルーティング）

```
src/routes/
├── users/
│   ├── me/
│   │   ├── get.ts                    # GET /users/me
│   │   ├── patch.ts                  # PATCH /users/me
│   │   ├── statistics/
│   │   │   └── get.ts                # GET /users/me/statistics
│   │   ├── attempts/
│   │   │   └── get.ts                # GET /users/me/attempts
│   │   ├── wrong-questions/
│   │   │   ├── get.ts                # GET /users/me/wrong-questions
│   │   │   ├── review/
│   │   │   │   └── post.ts           # POST /users/me/wrong-questions/review
│   │   │   └── _questionId/
│   │   │       └── master/
│   │   │           └── patch.ts      # PATCH /users/me/wrong-questions/:questionId/master
│   │   └── bookmarks/
│   │       ├── get.ts                # GET /users/me/bookmarks
│   │       ├── post.ts               # POST /users/me/bookmarks
│   │       └── _questionId/
│   │           ├── patch.ts          # PATCH /users/me/bookmarks/:questionId
│   │           └── delete.ts         # DELETE /users/me/bookmarks/:questionId
├── categories/
│   ├── get.ts                        # GET /categories
│   ├── post.ts                       # POST /categories
│   └── _id/
│       ├── patch.ts                  # PATCH /categories/:id
│       └── delete.ts                 # DELETE /categories/:id
├── tags/
│   ├── get.ts                        # GET /tags
│   ├── post.ts                       # POST /tags
│   └── _id/
│       ├── patch.ts                  # PATCH /tags/:id
│       └── delete.ts                 # DELETE /tags/:id
├── exams/
│   ├── get.ts                        # GET /exams
│   ├── post.ts                       # POST /exams
│   ├── my-exams/
│   │   └── get.ts                    # GET /exams/my-exams
│   └── _examId/
│       ├── get.ts                    # GET /exams/:examId
│       ├── patch.ts                  # PATCH /exams/:examId
│       ├── delete.ts                 # DELETE /exams/:examId
│       ├── status/
│       │   └── patch.ts              # PATCH /exams/:examId/status
│       ├── statistics/
│       │   └── get.ts                # GET /exams/:examId/statistics
│       ├── my-attempts/
│       │   └── get.ts                # GET /exams/:examId/my-attempts
│       ├── attempts/
│       │   └── post.ts               # POST /exams/:examId/attempts
│       └── questions/
│           ├── get.ts                # GET /exams/:examId/questions
│           ├── post.ts               # POST /exams/:examId/questions
│           ├── reorder/
│           │   └── patch.ts          # PATCH /exams/:examId/questions/reorder
│           └── _questionId/
│               ├── patch.ts          # PATCH /exams/:examId/questions/:questionId
│               └── delete.ts         # DELETE /exams/:examId/questions/:questionId
├── attempts/
│   └── _attemptId/
│       ├── get.ts                    # GET /attempts/:attemptId
│       ├── answers/
│       │   └── post.ts               # POST /attempts/:attemptId/answers
│       └── complete/
│           └── post.ts               # POST /attempts/:attemptId/complete
├── questions/
│   └── _questionId/
│       └── statistics/
│           └── get.ts                # GET /questions/:questionId/statistics
└── statistics/
    └── get.ts                        # GET /statistics (全体統計)
```

## エラーレスポンス

全てのエンドポイントで統一されたエラーレスポンス形式を使用します。

```json
{
  "error": "エラーメッセージ",
  "code": "ERROR_CODE",
  "statusCode": 400,
  "details": {
    "field": "追加情報"
  }
}
```

### エラーコード一覧

- `UNAUTHORIZED`: 認証エラー（401）
- `FORBIDDEN`: 権限エラー（403）
- `NOT_FOUND`: リソースが見つからない（404）
- `VALIDATION_ERROR`: バリデーションエラー（400）
- `EXAM_NOT_AVAILABLE`: 試験が受験可能期間外（400）
- `EXAM_ALREADY_STARTED`: 試験が既に開始されている（400）
- `EXAM_TIME_EXPIRED`: 試験時間が終了（400）
- `MAX_ATTEMPTS_REACHED`: 最大受験回数に達した（400）
- `INTERNAL_SERVER_ERROR`: サーバーエラー（500）

## ページネーション

リスト取得APIでは統一されたページネーション形式を使用します。

**クエリパラメータ**:

- `page`: ページ番号（デフォルト: 1）
- `limit`: 1ページあたりの件数（デフォルト: 20、最大: 100）

**レスポンス**:

```json
{
  "data": [],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 100,
    "totalPages": 5,
    "hasNext": true,
    "hasPrev": false
  }
}
```

## レート制限

- 一般ユーザー: 100リクエスト/分
- 認証済みユーザー: 1000リクエスト/分
- 管理者: 無制限

レート制限を超えた場合は`429 Too Many Requests`を返します。

## CORS設定

- 開発環境: 全てのオリジンを許可
- 本番環境: 指定されたフロントエンドドメインのみ許可

## 次のステップ

1. **Drizzle ORMスキーマ定義の作成**
2. **Zodバリデーションスキーマの設計**
3. **認証ミドルウェアの実装**
4. **各エンドポイントの実装**
