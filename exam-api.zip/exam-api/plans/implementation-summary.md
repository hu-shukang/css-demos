# 試験システム 実装計画サマリー

## プロジェクト概要

AWS Cognito認証を使用したオンライン試験システムのデータベース設計とAPI設計を完了しました。

## 完成したドキュメント

### 1. データベース設計 ([`database-design.md`](plans/database-design.md:1))

**主要テーブル（21テーブル）**:

- ユーザー管理: `users`
- カテゴリー管理: `exam_categories`, `exam_category_translations`
- タグ管理: `exam_tags`, `exam_tag_translations`, `exam_tag_relations`
- 試験管理: `exams`, `exam_translations`
- 問題管理: `questions`, `question_translations`, `choices`, `choice_translations`, `explanations`, `explanation_translations`
- 受験管理: `exam_attempts`, `user_answers`
- 学習支援: `wrong_questions`, `bookmarks`
- 統計情報: `user_statistics`, `exam_statistics`, `question_statistics`

**設計の特徴**:

- 翻訳テーブルによるコンテンツ管理（1対1関係）
- 論理削除による履歴保持
- 階層構造のカテゴリー管理
- 柔軟な時間制限設定（期間制限と制限時間の両方）
- 統計情報の集計テーブルでパフォーマンス最適化

### 2. APIエンドポイント設計 ([`api-design.md`](plans/api-design.md:1))

**主要エンドポイント（9カテゴリー、40以上のエンドポイント）**:

- ユーザー管理: `/users/me/*`
- カテゴリー管理: `/categories/*`
- タグ管理: `/tags/*`
- 試験管理: `/exams/*`
- 問題管理: `/exams/:examId/questions/*`
- 受験管理: `/attempts/*`
- 錯題集: `/users/me/wrong-questions/*`
- ブックマーク: `/users/me/bookmarks/*`
- 統計情報: `/statistics/*`

**設計の特徴**:

- RESTful API設計
- Fastifyのディレクトリベースルーティング
- 統一されたエラーレスポンス形式
- ページネーション対応
- レート制限の実装

### 3. Drizzle ORMスキーマ設計 ([`drizzle-schema-design.md`](plans/drizzle-schema-design.md:1))

**スキーマファイル構成**:

- `users.schema.ts`: ユーザー関連
- `categories.schema.ts`: カテゴリー関連
- `tags.schema.ts`: タグ関連
- `exams.schema.ts`: 試験関連
- `questions.schema.ts`: 問題関連
- `attempts.schema.ts`: 受験関連
- `statistics.schema.ts`: 統計関連

**設計の特徴**:

- 型安全なリレーション定義（1対1、1対多）
- 外部キー制約とカスケード削除
- ユニーク制約による重複防止
- インデックス最適化
- 型推論による自動型生成

### 4. Zodバリデーションスキーマ設計 ([`zod-schema-design.md`](plans/zod-schema-design.md:1))

**モデルファイル構成**:

- `user.model.ts`: ユーザー関連
- `category.model.ts`: カテゴリー関連
- `tag.model.ts`: タグ関連
- `exam.model.ts`: 試験関連
- `question.model.ts`: 問題関連
- `attempt.model.ts`: 受験関連
- `wrong-question.model.ts`: 錯題集関連
- `bookmark.model.ts`: ブックマーク関連
- `statistics.model.ts`: 統計関連

**設計の特徴**:

- `SCHEMA.z`パターンによる共通スキーマの再利用
- 複雑なバリデーションルール（`.refine()`）
- 日本語のエラーメッセージ
- 型推論による自動型生成
- 単一言語のコンテンツ管理に簡素化

## 推奨機能（実装済み設計）

1. **試験カテゴリー・タグ機能**: 試験を分類して検索しやすく
2. **問題のランダム出題**: 不正防止と学習効果向上
3. **学習進捗管理**: カテゴリーごとの正答率と弱点分析
4. **問題の難易度設定**: ユーザーレベルに応じた問題推薦
5. **解説の充実**: 正解・不正解の両方に解説と参考リンク
6. **試験の公開設定**: 公開/非公開/限定公開の制御
7. **統計情報**: 試験・問題ごとの詳細な統計
8. **復習モード**: 錯題のみを集めた復習セッション
9. **ブックマーク機能**: 重要な問題をマーク
10. **試験のバージョン管理**: 更新履歴の保持

## 技術スタック

- **バックエンド**: Fastify + TypeScript
- **ORM**: Drizzle ORM
- **バリデーション**: Zod
- **データベース**: PostgreSQL
- **認証**: AWS Cognito
- **テスト**: Jest + Testcontainers

## 次のステップ（実装フェーズ）

### フェーズ1: 基盤構築

1. Drizzle ORMスキーマファイルの作成
2. マイグレーションファイルの生成と実行
3. Zodバリデーションスキーマの実装
4. 認証ミドルウェアの実装（Cognito JWT検証）

### フェーズ2: コア機能実装

1. ユーザー管理API
2. カテゴリー・タグ管理API
3. 試験管理API（CRUD）
4. 問題管理API（CRUD）

### フェーズ3: 受験機能実装

1. 受験開始・解答保存・完了API
2. 採点ロジックの実装
3. 錯題集の自動更新
4. 統計情報の集計処理

### フェーズ4: 学習支援機能

1. 錯題集API
2. ブックマークAPI
3. 学習進捗管理
4. 復習モード

### フェーズ5: 統計・分析機能

1. ユーザー統計API
2. 試験統計API
3. 問題統計API
4. ダッシュボード用データ集計

### フェーズ6: テストとドキュメント

1. ユニットテストの作成
2. 統合テストの作成
3. API仕様書の生成（Swagger）
4. パフォーマンステスト

## ファイル構造（実装時）

```
src/
├── db/
│   ├── schema/
│   │   ├── users.schema.ts
│   │   ├── categories.schema.ts
│   │   ├── tags.schema.ts
│   │   ├── exams.schema.ts
│   │   ├── questions.schema.ts
│   │   ├── attempts.schema.ts
│   │   ├── statistics.schema.ts
│   │   └── index.ts
│   └── migrations/
├── models/
│   ├── user.model.ts
│   ├── category.model.ts
│   ├── tag.model.ts
│   ├── exam.model.ts
│   ├── question.model.ts
│   ├── attempt.model.ts
│   ├── wrong-question.model.ts
│   ├── bookmark.model.ts
│   ├── statistics.model.ts
│   └── common.model.ts
├── routes/
│   ├── users/
│   ├── categories/
│   ├── tags/
│   ├── exams/
│   ├── attempts/
│   ├── questions/
│   └── statistics/
├── services/
│   ├── auth.service.ts
│   ├── exam.service.ts
│   ├── question.service.ts
│   ├── attempt.service.ts
│   └── statistics.service.ts
├── middlewares/
│   ├── auth.middleware.ts
│   └── permission.middleware.ts
└── utils/
    ├── const.util.ts
    ├── logger.util.ts
    └── als.util.ts
```

## 重要な設計判断

### 1. 翻訳テーブルの実装方法

**選択**: 1対1の翻訳テーブル方式（各エンティティに対して`_translations`テーブル）

**理由**:

- コンテンツとメタデータの分離
- クエリが単純（JOINで取得）
- データの整合性が保ちやすい
- 将来的な多言語対応への拡張が容易

### 2. 統計情報の管理

**選択**: 集計テーブル方式（`user_statistics`, `exam_statistics`, `question_statistics`）

**理由**:

- 頻繁なクエリのパフォーマンス向上
- リアルタイム集計の負荷軽減
- バッチ処理での更新が可能

### 3. 錯題集の自動管理

**選択**: `wrong_questions`テーブルで自動記録

**理由**:

- ユーザーの弱点を自動的に追跡
- 復習モードの実装が容易
- 学習効果の可視化

### 4. 時間制限の柔軟性

**選択**: 期間制限（`available_from`/`available_until`）と制限時間（`time_limit_minutes`）の両方をサポート

**理由**:

- 様々な試験形式に対応
- 企業研修や資格試験など多様なユースケース
- NULL許可で柔軟な設定

## パフォーマンス最適化のポイント

1. **インデックス**: 頻繁にクエリされるカラムにインデックスを追加
2. **集計テーブル**: 統計情報を事前集計
3. **ページネーション**: 大量データの取得を制限
4. **論理削除**: 物理削除を避けて履歴を保持
5. **リレーションクエリ**: Drizzle ORMの型安全なリレーションクエリを活用

## セキュリティ考慮事項

1. **認証**: AWS Cognito JWTトークンによる認証
2. **認可**: ユーザーロール（一般/作成者/管理者）による権限制御
3. **データ検証**: Zodによる厳密なバリデーション
4. **SQLインジェクション対策**: Drizzle ORMのパラメータ化クエリ
5. **レート制限**: APIのレート制限実装

## まとめ

PostgreSQLのテーブル設計、APIエンドポイント設計、Drizzle ORMスキーマ設計、Zodバリデーションスキーマ設計が完了しました。

この設計は以下の要件を満たしています:

- ✅ 試験・問題・選択肢・解説の管理
- ✅ オンライン答題機能
- ✅ 答題結果の履歴記録と折れ線グラフ表示
- ✅ 錯題集機能
- ✅ AWS Cognito認証連携
- ✅ 10の追加推奨機能
- ✅ 単一言語のシンプルなコンテンツ管理

実装フェーズに進む準備が整いました。
