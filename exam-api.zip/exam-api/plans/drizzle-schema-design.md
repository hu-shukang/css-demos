# Drizzle ORM スキーマ定義設計

## 概要

このドキュメントでは、試験システムのDrizzle ORMスキーマ定義を提供します。
既存のプロジェクト構造に従い、[`src/plugins/04.db.plugin.ts`](src/plugins/04.db.plugin.ts:1)で使用されるスキーマを定義します。

## ディレクトリ構造

```
src/
├── db/
│   ├── schema/
│   │   ├── users.schema.ts           # ユーザー関連スキーマ
│   │   ├── categories.schema.ts      # カテゴリー関連スキーマ
│   │   ├── tags.schema.ts            # タグ関連スキーマ
│   │   ├── exams.schema.ts           # 試験関連スキーマ
│   │   ├── questions.schema.ts       # 問題関連スキーマ
│   │   ├── attempts.schema.ts        # 受験関連スキーマ
│   │   ├── statistics.schema.ts      # 統計関連スキーマ
│   │   └── index.ts                  # 全スキーマのエクスポート
│   └── migrations/                   # マイグレーションファイル
└── plugins/
    └── 04.db.plugin.ts               # DBプラグイン
```

## スキーマ定義

### 1. users.schema.ts

```typescript
import { relations } from 'drizzle-orm';
import { pgTable, timestamp, uuid, varchar } from 'drizzle-orm/pg-core';

// ===================================
// Users Table
// ===================================
export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  cognitoSub: varchar('cognito_sub', { length: 255 }).notNull().unique(),
  username: varchar('username', { length: 100 }).notNull(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
});

// ===================================
// Relations
// ===================================
export const usersRelations = relations(users, ({ many }) => ({
  exams: many(exams),
  examAttempts: many(examAttempts),
  wrongQuestions: many(wrongQuestions),
  bookmarks: many(bookmarks),
  userStatistics: many(userStatistics),
}));

// ===================================
// Types
// ===================================
export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
```

### 2. categories.schema.ts

```typescript
import { relations } from 'drizzle-orm';
import { integer, pgTable, text, timestamp, uuid, varchar } from 'drizzle-orm/pg-core';

// ===================================
// Exam Categories Table
// ===================================
export const examCategories = pgTable('exam_categories', {
  id: uuid('id').primaryKey().defaultRandom(),
  parentId: uuid('parent_id').references(() => examCategories.id, { onDelete: 'set null' }),
  name: varchar('name', { length: 200 }).notNull(),
  description: text('description'),
  sortOrder: integer('sort_order').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
});

// ===================================
// Relations
// ===================================
export const examCategoriesRelations = relations(examCategories, ({ one, many }) => ({
  parent: one(examCategories, {
    fields: [examCategories.parentId],
    references: [examCategories.id],
  }),
  children: many(examCategories),
  exams: many(exams),
  userStatistics: many(userStatistics),
}));

// ===================================
// Types
// ===================================
export type ExamCategory = typeof examCategories.$inferSelect;
export type NewExamCategory = typeof examCategories.$inferInsert;
```

### 3. tags.schema.ts

```typescript
import { relations } from 'drizzle-orm';
import { pgTable, primaryKey, timestamp, uuid, varchar } from 'drizzle-orm/pg-core';

// ===================================
// Exam Tags Table
// ===================================
export const examTags = pgTable('exam_tags', {
  id: uuid('id').primaryKey().defaultRandom(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
});

// ===================================
// Exam Tag Translations Table
// ===================================
export const examTagTranslations = pgTable('exam_tag_translations', {
  id: uuid('id').primaryKey().defaultRandom(),
  tagId: uuid('tag_id')
    .notNull()
    .unique()
    .references(() => examTags.id, { onDelete: 'cascade' }),
  name: varchar('name', { length: 100 }).notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Exam Tag Relations Table (Many-to-Many)
// ===================================
export const examTagRelations = pgTable(
  'exam_tag_relations',
  {
    examId: uuid('exam_id')
      .notNull()
      .references(() => exams.id, { onDelete: 'cascade' }),
    tagId: uuid('tag_id')
      .notNull()
      .references(() => examTags.id, { onDelete: 'cascade' }),
    createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.examId, table.tagId] }),
  }),
);

// ===================================
// Relations
// ===================================
export const examTagsRelations = relations(examTags, ({ one, many }) => ({
  translations: one(examTagTranslations),
  examRelations: many(examTagRelations),
}));

export const examTagTranslationsRelations = relations(examTagTranslations, ({ one }) => ({
  tag: one(examTags, {
    fields: [examTagTranslations.tagId],
    references: [examTags.id],
  }),
}));

export const examTagRelationsRelations = relations(examTagRelations, ({ one }) => ({
  exam: one(exams, {
    fields: [examTagRelations.examId],
    references: [exams.id],
  }),
  tag: one(examTags, {
    fields: [examTagRelations.tagId],
    references: [examTags.id],
  }),
}));

// ===================================
// Types
// ===================================
export type ExamTag = typeof examTags.$inferSelect;
export type NewExamTag = typeof examTags.$inferInsert;
export type ExamTagTranslation = typeof examTagTranslations.$inferSelect;
export type NewExamTagTranslation = typeof examTagTranslations.$inferInsert;
export type ExamTagRelation = typeof examTagRelations.$inferSelect;
export type NewExamTagRelation = typeof examTagRelations.$inferInsert;
```

### 4. exams.schema.ts

```typescript
import { relations } from 'drizzle-orm';
import { boolean, integer, pgTable, text, timestamp, uuid, varchar } from 'drizzle-orm/pg-core';

// ===================================
// Exams Table
// ===================================
export const exams = pgTable('exams', {
  id: uuid('id').primaryKey().defaultRandom(),
  categoryId: uuid('category_id').references(() => examCategories.id, { onDelete: 'set null' }),
  createdBy: uuid('created_by')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  status: varchar('status', { length: 20 }).notNull().default('draft'), // draft, published, archived
  difficultyLevel: varchar('difficulty_level', { length: 20 }), // beginner, intermediate, advanced
  passingScore: integer('passing_score').notNull(),
  totalScore: integer('total_score').notNull(),
  timeLimitMinutes: integer('time_limit_minutes'),
  availableFrom: timestamp('available_from', { withTimezone: true }),
  availableUntil: timestamp('available_until', { withTimezone: true }),
  isRandomOrder: boolean('is_random_order').notNull().default(false),
  maxAttempts: integer('max_attempts'),
  showCorrectAnswers: boolean('show_correct_answers').notNull().default(true),
  showExplanations: boolean('show_explanations').notNull().default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
});

// ===================================
// Exam Translations Table
// ===================================
export const examTranslations = pgTable('exam_translations', {
  id: uuid('id').primaryKey().defaultRandom(),
  examId: uuid('exam_id')
    .notNull()
    .unique()
    .references(() => exams.id, { onDelete: 'cascade' }),
  title: varchar('title', { length: 500 }).notNull(),
  description: text('description'),
  instructions: text('instructions'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Relations
// ===================================
export const examsRelations = relations(exams, ({ one, many }) => ({
  category: one(examCategories, {
    fields: [exams.categoryId],
    references: [examCategories.id],
  }),
  creator: one(users, {
    fields: [exams.createdBy],
    references: [users.id],
  }),
  translations: one(examTranslations),
  tagRelations: many(examTagRelations),
  questions: many(questions),
  examAttempts: many(examAttempts),
  statistics: one(examStatistics),
}));

export const examTranslationsRelations = relations(examTranslations, ({ one }) => ({
  exam: one(exams, {
    fields: [examTranslations.examId],
    references: [exams.id],
  }),
}));

// ===================================
// Types
// ===================================
export type Exam = typeof exams.$inferSelect;
export type NewExam = typeof exams.$inferInsert;
export type ExamTranslation = typeof examTranslations.$inferSelect;
export type NewExamTranslation = typeof examTranslations.$inferInsert;
```

### 5. questions.schema.ts

```typescript
import { relations } from 'drizzle-orm';
import { boolean, integer, pgTable, text, timestamp, uuid, varchar } from 'drizzle-orm/pg-core';

// ===================================
// Questions Table
// ===================================
export const questions = pgTable('questions', {
  id: uuid('id').primaryKey().defaultRandom(),
  examId: uuid('exam_id')
    .notNull()
    .references(() => exams.id, { onDelete: 'cascade' }),
  questionType: varchar('question_type', { length: 20 }).notNull(), // single, multiple
  points: integer('points').notNull().default(1),
  sortOrder: integer('sort_order').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
});

// ===================================
// Question Translations Table
// ===================================
export const questionTranslations = pgTable('question_translations', {
  id: uuid('id').primaryKey().defaultRandom(),
  questionId: uuid('question_id')
    .notNull()
    .unique()
    .references(() => questions.id, { onDelete: 'cascade' }),
  questionText: text('question_text').notNull(),
  hint: text('hint'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Choices Table
// ===================================
export const choices = pgTable('choices', {
  id: uuid('id').primaryKey().defaultRandom(),
  questionId: uuid('question_id')
    .notNull()
    .references(() => questions.id, { onDelete: 'cascade' }),
  isCorrect: boolean('is_correct').notNull().default(false),
  sortOrder: integer('sort_order').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
  deletedAt: timestamp('deleted_at', { withTimezone: true }),
});

// ===================================
// Choice Translations Table
// ===================================
export const choiceTranslations = pgTable('choice_translations', {
  id: uuid('id').primaryKey().defaultRandom(),
  choiceId: uuid('choice_id')
    .notNull()
    .unique()
    .references(() => choices.id, { onDelete: 'cascade' }),
  choiceText: text('choice_text').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Explanations Table
// ===================================
export const explanations = pgTable('explanations', {
  id: uuid('id').primaryKey().defaultRandom(),
  questionId: uuid('question_id')
    .notNull()
    .references(() => questions.id, { onDelete: 'cascade' }),
  choiceId: uuid('choice_id').references(() => choices.id, { onDelete: 'cascade' }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Explanation Translations Table
// ===================================
export const explanationTranslations = pgTable('explanation_translations', {
  id: uuid('id').primaryKey().defaultRandom(),
  explanationId: uuid('explanation_id')
    .notNull()
    .unique()
    .references(() => explanations.id, { onDelete: 'cascade' }),
  explanationText: text('explanation_text').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Relations
// ===================================
export const questionsRelations = relations(questions, ({ one, many }) => ({
  exam: one(exams, {
    fields: [questions.examId],
    references: [exams.id],
  }),
  translations: one(questionTranslations),
  choices: many(choices),
  explanations: many(explanations),
  userAnswers: many(userAnswers),
  wrongQuestions: many(wrongQuestions),
  bookmarks: many(bookmarks),
  statistics: one(questionStatistics),
}));

export const questionTranslationsRelations = relations(questionTranslations, ({ one }) => ({
  question: one(questions, {
    fields: [questionTranslations.questionId],
    references: [questions.id],
  }),
}));

export const choicesRelations = relations(choices, ({ one, many }) => ({
  question: one(questions, {
    fields: [choices.questionId],
    references: [questions.id],
  }),
  translations: one(choiceTranslations),
  explanations: many(explanations),
  userAnswers: many(userAnswers),
}));

export const choiceTranslationsRelations = relations(choiceTranslations, ({ one }) => ({
  choice: one(choices, {
    fields: [choiceTranslations.choiceId],
    references: [choices.id],
  }),
}));

export const explanationsRelations = relations(explanations, ({ one, many }) => ({
  question: one(questions, {
    fields: [explanations.questionId],
    references: [questions.id],
  }),
  choice: one(choices, {
    fields: [explanations.choiceId],
    references: [choices.id],
  }),
  translations: one(explanationTranslations),
}));

export const explanationTranslationsRelations = relations(explanationTranslations, ({ one }) => ({
  explanation: one(explanations, {
    fields: [explanationTranslations.explanationId],
    references: [explanations.id],
  }),
}));

// ===================================
// Types
// ===================================
export type Question = typeof questions.$inferSelect;
export type NewQuestion = typeof questions.$inferInsert;
export type QuestionTranslation = typeof questionTranslations.$inferSelect;
export type NewQuestionTranslation = typeof questionTranslations.$inferInsert;
export type Choice = typeof choices.$inferSelect;
export type NewChoice = typeof choices.$inferInsert;
export type ChoiceTranslation = typeof choiceTranslations.$inferSelect;
export type NewChoiceTranslation = typeof choiceTranslations.$inferInsert;
export type Explanation = typeof explanations.$inferSelect;
export type NewExplanation = typeof explanations.$inferInsert;
export type ExplanationTranslation = typeof explanationTranslations.$inferSelect;
export type NewExplanationTranslation = typeof explanationTranslations.$inferInsert;
```

### 6. attempts.schema.ts

```typescript
import { relations } from 'drizzle-orm';
import { boolean, integer, pgTable, text, timestamp, uuid, varchar } from 'drizzle-orm/pg-core';

// ===================================
// Exam Attempts Table
// ===================================
export const examAttempts = pgTable('exam_attempts', {
  id: uuid('id').primaryKey().defaultRandom(),
  examId: uuid('exam_id')
    .notNull()
    .references(() => exams.id, { onDelete: 'cascade' }),
  userId: uuid('user_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  attemptNumber: integer('attempt_number').notNull(),
  status: varchar('status', { length: 20 }).notNull().default('in_progress'), // in_progress, completed, abandoned
  score: integer('score'),
  totalScore: integer('total_score'),
  isPassed: boolean('is_passed'),
  startedAt: timestamp('started_at', { withTimezone: true }).notNull().defaultNow(),
  completedAt: timestamp('completed_at', { withTimezone: true }),
  timeSpentSeconds: integer('time_spent_seconds'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// User Answers Table
// ===================================
export const userAnswers = pgTable('user_answers', {
  id: uuid('id').primaryKey().defaultRandom(),
  attemptId: uuid('attempt_id')
    .notNull()
    .references(() => examAttempts.id, { onDelete: 'cascade' }),
  questionId: uuid('question_id')
    .notNull()
    .references(() => questions.id, { onDelete: 'cascade' }),
  choiceId: uuid('choice_id')
    .notNull()
    .references(() => choices.id, { onDelete: 'cascade' }),
  isCorrect: boolean('is_correct').notNull(),
  pointsEarned: integer('points_earned').notNull().default(0),
  answeredAt: timestamp('answered_at', { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Wrong Questions Table
// ===================================
export const wrongQuestions = pgTable('wrong_questions', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  questionId: uuid('question_id')
    .notNull()
    .references(() => questions.id, { onDelete: 'cascade' }),
  wrongCount: integer('wrong_count').notNull().default(1),
  lastWrongAt: timestamp('last_wrong_at', { withTimezone: true }).notNull().defaultNow(),
  isMastered: boolean('is_mastered').notNull().default(false),
  masteredAt: timestamp('mastered_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Bookmarks Table
// ===================================
export const bookmarks = pgTable('bookmarks', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  questionId: uuid('question_id')
    .notNull()
    .references(() => questions.id, { onDelete: 'cascade' }),
  note: text('note'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Relations
// ===================================
export const examAttemptsRelations = relations(examAttempts, ({ one, many }) => ({
  exam: one(exams, {
    fields: [examAttempts.examId],
    references: [exams.id],
  }),
  user: one(users, {
    fields: [examAttempts.userId],
    references: [users.id],
  }),
  userAnswers: many(userAnswers),
}));

export const userAnswersRelations = relations(userAnswers, ({ one }) => ({
  attempt: one(examAttempts, {
    fields: [userAnswers.attemptId],
    references: [examAttempts.id],
  }),
  question: one(questions, {
    fields: [userAnswers.questionId],
    references: [questions.id],
  }),
  choice: one(choices, {
    fields: [userAnswers.choiceId],
    references: [choices.id],
  }),
}));

export const wrongQuestionsRelations = relations(wrongQuestions, ({ one }) => ({
  user: one(users, {
    fields: [wrongQuestions.userId],
    references: [users.id],
  }),
  question: one(questions, {
    fields: [wrongQuestions.questionId],
    references: [questions.id],
  }),
}));

export const bookmarksRelations = relations(bookmarks, ({ one }) => ({
  user: one(users, {
    fields: [bookmarks.userId],
    references: [users.id],
  }),
  question: one(questions, {
    fields: [bookmarks.questionId],
    references: [questions.id],
  }),
}));

// ===================================
// Types
// ===================================
export type ExamAttempt = typeof examAttempts.$inferSelect;
export type NewExamAttempt = typeof examAttempts.$inferInsert;
export type UserAnswer = typeof userAnswers.$inferSelect;
export type NewUserAnswer = typeof userAnswers.$inferInsert;
export type WrongQuestion = typeof wrongQuestions.$inferSelect;
export type NewWrongQuestion = typeof wrongQuestions.$inferInsert;
export type Bookmark = typeof bookmarks.$inferSelect;
export type NewBookmark = typeof bookmarks.$inferInsert;
```

### 7. statistics.schema.ts

```typescript
import { relations } from 'drizzle-orm';
import { decimal, integer, pgTable, timestamp, uuid } from 'drizzle-orm/pg-core';

// ===================================
// User Statistics Table
// ===================================
export const userStatistics = pgTable('user_statistics', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id')
    .notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  categoryId: uuid('category_id').references(() => examCategories.id, { onDelete: 'cascade' }),
  totalAttempts: integer('total_attempts').notNull().default(0),
  totalQuestions: integer('total_questions').notNull().default(0),
  correctAnswers: integer('correct_answers').notNull().default(0),
  accuracyRate: decimal('accuracy_rate', { precision: 5, scale: 2 }).notNull().default('0'),
  totalStudyTimeSeconds: integer('total_study_time_seconds').notNull().default(0),
  lastStudiedAt: timestamp('last_studied_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Exam Statistics Table
// ===================================
export const examStatistics = pgTable('exam_statistics', {
  id: uuid('id').primaryKey().defaultRandom(),
  examId: uuid('exam_id')
    .notNull()
    .references(() => exams.id, { onDelete: 'cascade' })
    .unique(),
  totalAttempts: integer('total_attempts').notNull().default(0),
  uniqueUsers: integer('unique_users').notNull().default(0),
  averageScore: decimal('average_score', { precision: 5, scale: 2 }).notNull().default('0'),
  passRate: decimal('pass_rate', { precision: 5, scale: 2 }).notNull().default('0'),
  averageTimeSeconds: integer('average_time_seconds').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Question Statistics Table
// ===================================
export const questionStatistics = pgTable('question_statistics', {
  id: uuid('id').primaryKey().defaultRandom(),
  questionId: uuid('question_id')
    .notNull()
    .references(() => questions.id, { onDelete: 'cascade' })
    .unique(),
  totalAnswers: integer('total_answers').notNull().default(0),
  correctAnswers: integer('correct_answers').notNull().default(0),
  accuracyRate: decimal('accuracy_rate', { precision: 5, scale: 2 }).notNull().default('0'),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }),
});

// ===================================
// Relations
// ===================================
export const userStatisticsRelations = relations(userStatistics, ({ one }) => ({
  user: one(users, {
    fields: [userStatistics.userId],
    references: [users.id],
  }),
  category: one(examCategories, {
    fields: [userStatistics.categoryId],
    references: [examCategories.id],
  }),
}));

export const examStatisticsRelations = relations(examStatistics, ({ one }) => ({
  exam: one(exams, {
    fields: [examStatistics.examId],
    references: [exams.id],
  }),
}));

export const questionStatisticsRelations = relations(questionStatistics, ({ one }) => ({
  question: one(questions, {
    fields: [questionStatistics.questionId],
    references: [questions.id],
  }),
}));

// ===================================
// Types
// ===================================
export type UserStatistic = typeof userStatistics.$inferSelect;
export type NewUserStatistic = typeof userStatistics.$inferInsert;
export type ExamStatistic = typeof examStatistics.$inferSelect;
export type NewExamStatistic = typeof examStatistics.$inferInsert;
export type QuestionStatistic = typeof questionStatistics.$inferSelect;
export type NewQuestionStatistic = typeof questionStatistics.$inferInsert;
```

### 8. index.ts（全スキーマのエクスポート）

```typescript
// ===================================
// Export all schemas
// ===================================
export * from './users.schema.js';
export * from './categories.schema.js';
export * from './tags.schema.js';
export * from './exams.schema.js';
export * from './questions.schema.js';
export * from './attempts.schema.js';
export * from './statistics.schema.js';
```

## DBプラグインの更新

[`src/plugins/04.db.plugin.ts`](src/plugins/04.db.plugin.ts:1)を更新して、スキーマを含める必要があります。

```typescript
import { drizzle } from 'drizzle-orm/node-postgres';
import { FastifyPluginAsync } from 'fastify';
import fp from 'fastify-plugin';
import { Pool } from 'pg';

import * as schema from '@/db/schema/index.js';

const dbPlugin: FastifyPluginAsync = fp(async (fastify) => {
  const pool = new Pool({
    connectionString: fastify.config.DATABASE_URL,
  });
  const db = drizzle({ client: pool, schema });
  fastify.decorate('db', db);
});

export default dbPlugin;
```

## 型定義の更新

[`src/type.d.ts`](src/type.d.ts:1)を更新して、DBの型を追加します。

```typescript
import { NodePgDatabase } from 'drizzle-orm/node-postgres';

import * as schema from '@/db/schema/index.js';

declare module 'fastify' {
  interface FastifyInstance {
    config: {
      DATABASE_URL: string;
      // ... 他の環境変数
    };
    db: NodePgDatabase<typeof schema>;
  }
}
```

## Drizzle設定ファイル

プロジェクトルートに`drizzle.config.ts`を作成します。

```typescript
import * as dotenv from 'dotenv';
import type { Config } from 'drizzle-kit';

dotenv.config({ path: 'env/.env' });

export default {
  schema: './src/db/schema/*.schema.ts',
  out: './src/db/migrations',
  dialect: 'postgresql',
  dbCredentials: {
    url: process.env.DATABASE_URL!,
  },
  verbose: true,
  strict: true,
} satisfies Config;
```

## マイグレーションコマンド

[`package.json`](package.json:1)にマイグレーション関連のスクリプトを追加します。

```json
{
  "scripts": {
    "db:generate": "drizzle-kit generate",
    "db:migrate": "drizzle-kit migrate",
    "db:push": "drizzle-kit push",
    "db:studio": "drizzle-kit studio"
  }
}
```

## 使用例

### 1. ユーザーの作成

```typescript
import { users } from '@/db/schema/index.js';

// ルートハンドラー内
const newUser = await fastify.db
  .insert(users)
  .values({
    cognitoSub: 'cognito-sub-id',
    username: 'testuser',
    email: 'test@example.com',
  })
  .returning();
```

### 2. 試験の取得（リレーション含む）

```typescript
import { eq } from 'drizzle-orm';

import { examTranslations, exams, questions } from '@/db/schema/index.js';

const exam = await fastify.db.query.exams.findFirst({
  where: eq(exams.id, examId),
  with: {
    translations: true,
    questions: {
      with: {
        translations: true,
        choices: {
          with: {
            translations: true,
          },
        },
      },
    },
  },
});
```

### 3. 受験履歴の取得

```typescript
import { and, desc, eq } from 'drizzle-orm';

import { examAttempts, examTranslations, exams } from '@/db/schema/index.js';

const attempts = await fastify.db.query.examAttempts.findMany({
  where: and(eq(examAttempts.userId, userId), eq(examAttempts.examId, examId), eq(examAttempts.status, 'completed')),
  orderBy: [desc(examAttempts.attemptNumber)],
  with: {
    exam: {
      with: {
        translations: true,
      },
    },
  },
});
```

### 4. 統計情報の更新

```typescript
import { eq, sql } from 'drizzle-orm';

import { examStatistics } from '@/db/schema/index.js';

await fastify.db
  .update(examStatistics)
  .set({
    totalAttempts: sql`${examStatistics.totalAttempts} + 1`,
    updatedAt: new Date(),
  })
  .where(eq(examStatistics.examId, examId));
```

## インデックスの追加

パフォーマンス最適化のため、頻繁にクエリされるカラムにインデックスを追加します。

```typescript
import { index } from 'drizzle-orm/pg-core';

// 例：usersテーブルにインデックスを追加
export const users = pgTable(
  'users',
  {
    // ... カラム定義
  },
  (table) => ({
    cognitoSubIdx: index('users_cognito_sub_idx').on(table.cognitoSub),
    emailIdx: index('users_email_idx').on(table.email),
    deletedAtIdx: index('users_deleted_at_idx').on(table.deletedAt),
  }),
);
```

## 注意事項

1. **unique制約**: `.unique()`メソッドを使用して単一カラムのユニーク制約を定義
2. **外部キー**: `references()`で外部キー制約を定義、`onDelete`で削除時の動作を指定
3. **リレーション**: `relations()`で型安全なリレーションクエリを実現（1対1関係は`one`、1対多関係は`many`）
4. **型推論**: `$inferSelect`と`$inferInsert`で型を自動生成
5. **マイグレーション**: スキーマ変更時は必ず`npm run db:generate`でマイグレーションファイルを生成

## 次のステップ

1. **Zodバリデーションスキーマの設計**
2. **マイグレーションファイルの生成と実行**
3. **各エンドポイントでのDB操作の実装**
