# AGENTS.md

このファイルは、このリポジトリのコードを扱う際にAIエージェントにガイダンスを提供します。

## プロジェクト固有の重要事項

### ファイル命名規則と読み込み順序

- **プラグインとフック**は数字プレフィックスで読み込み順序を制御（例：[`01.env.plugin.ts`](src/plugins/01.env.plugin.ts:1)、[`99.error-handler.plugin.ts`](src/plugins/99.error-handler.plugin.ts:1)）
- 環境変数プラグイン（01）は最初に、エラーハンドラー（99）は最後に読み込む必要がある
- フックも同様：[`01.request.hook.ts`](src/hooks/01.request.hook.ts:1)（リクエスト初期化）→ [`99.response.hook.ts`](src/hooks/99.response.hook.ts:1)（レスポンス処理）

### autoloadの matchFilter パターン

- [`src/app.ts`](src/app.ts:34)でプラグインは`matchFilter: (path) => path.includes('plugin')`を使用
- フックは`matchFilter: (path) => path.includes('hook')`を使用
- **新しいファイルには必ず`.plugin.ts`または`.hook.ts`サフィックスを付ける**

### AsyncLocalStorage (ALS) パターン

- [`src/utils/als.util.ts`](src/utils/als.util.ts:1)でリクエストスコープのロガーを管理
- [`src/utils/logger.util.ts`](src/utils/logger.util.ts:1)はALSからロガーを取得するプロキシ
- **ビジネスロジックでは`logger`をインポート、フック内では`request.log`を使用**

### Zodスキーマの一元管理

- [`src/utils/const.util.ts`](src/utils/const.util.ts:1)の`SCHEMA.z`に全てのZodスキーマ定義を集約
- モデルファイル（[`src/models/`](src/models/)）では`SCHEMA.z`から再利用してスキーマを構築
- **新しいフィールドは`SCHEMA.z`に追加し、モデルで参照する**

### 環境変数の型安全性

- [`src/type.d.ts`](src/type.d.ts:10)で`fastify.config`の型を定義
- [`src/plugins/01.env.plugin.ts`](src/plugins/01.env.plugin.ts:1)で`@fastify/env`を使用してバリデーション
- **新しい環境変数は両方のファイルに追加する必要がある**

### ルーティングの規約

- [`src/routes/`](src/routes/)配下で`dirNameRoutePrefix: true`を使用
- `_id`ディレクトリは`:id`パラメータに変換される（例：[`src/routes/book/_id/get.ts`](src/routes/book/_id/get.ts:1) → `/book/:id`）
- **動的パラメータには`_`プレフィックスを使用**

### テスト環境

- [`tests/global-setup.ts`](tests/global-setup.ts:1)で`@testcontainers/postgresql`を使用してPostgreSQLコンテナを起動
- [`tests/helpers/fastify.helper.ts`](tests/helpers/fastify.helper.ts:10)の`setupFastify()`でテストごとにFastifyインスタンスを管理
- **テストでは`getApp()`を使用してインスタンスを取得**

### ビルドとパスエイリアス

- `npm run build`は`tsc`と`tsc-alias`の両方を実行（[`package.json`](package.json:8)）
- **`tsc-alias`は`@/*`パスエイリアスを実際のパスに変換するために必須**

### 開発環境の起動

- `npm run dev`は`dotenv -e env/.env`で環境変数を読み込む（[`package.json`](package.json:7)）
- **環境変数ファイルは`env/.env`に配置する**

### Prettierのインポート順序

- [`prettier.config.mjs`](prettier.config.mjs:12)で`@trivago/prettier-plugin-sort-imports`を使用
- インポート順序：`tsconfig-paths/register` → サードパーティ → `@/*` → 相対パス
- **自動フォーマットでインポートが並び替えられる**

### ESLintの特殊ルール

- [`eslint.config.mjs`](eslint.config.mjs:18)で`**/*swagger.plugin.ts`を除外
- 未使用変数は`_`プレフィックスで無視（[`eslint.config.mjs`](eslint.config.mjs:25)）
- **Swaggerプラグインは型エラーを無視するため除外されている**
