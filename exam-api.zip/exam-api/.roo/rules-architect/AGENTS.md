# AGENTS.md (Architect Mode)

アーキテクチャ上の非自明な制約と設計パターン

## プラグイン/フックの読み込み順序制御

### 数字プレフィックスパターン

- **01-99の数字プレフィックスで読み込み順序を制御**
- [`src/app.ts`](src/app.ts:32)で`@fastify/autoload`を使用
- ファイルシステムの順序に依存せず、明示的に順序を制御

### 重要な順序制約

1. **01.env.plugin.ts** - 最初に読み込む必要がある（他のプラグインが`fastify.config`に依存）
2. **99.error-handler.plugin.ts** - 最後に読み込む必要がある（全てのエラーをキャッチ）
3. **01.request.hook.ts** - 最初に実行（ALSの初期化）
4. **99.response.hook.ts** - 最後に実行（共通ヘッダーの設定）

## AsyncLocalStorage (ALS) パターン

### 設計目的

- リクエストスコープのコンテキスト管理
- グローバル変数を使わずにリクエスト固有のデータを共有
- ロガーにリクエストIDを自動的に含める

### 実装の詳細

- [`src/utils/als.util.ts`](src/utils/als.util.ts:1) - ALSの定義
- [`src/hooks/01.request.hook.ts`](src/hooks/01.request.hook.ts:13) - ALSの初期化
- [`src/utils/logger.util.ts`](src/utils/logger.util.ts:1) - ALSからロガーを取得するプロキシ

### 制約

- **ALSは`01.request.hook.ts`で初期化されるため、フック外では`console`にフォールバック**

## Zodスキーマの一元管理パターン

### 設計目的

- スキーマの再利用性を高める
- バリデーションルールの一元管理
- エラーメッセージの統一

### 実装の詳細

- [`src/utils/const.util.ts`](src/utils/const.util.ts:1)の`SCHEMA.z`に全てのZodスキーマ定義を集約
- モデルファイル（[`src/models/`](src/models/)）では`SCHEMA.z`から参照

### 拡張方法

1. `SCHEMA.z`に新しいフィールド定義を追加
2. モデルファイルで`SCHEMA.z.xxx`を参照してスキーマを構築

## ルーティングの規約

### ディレクトリベースルーティング

- [`src/app.ts`](src/app.ts:42)で`dirNameRoutePrefix: true`を使用
- ディレクトリ名がルートプレフィックスになる

### 動的パラメータ

- `_`プレフィックスのディレクトリは動的パラメータに変換
- 例：`src/routes/book/_id/get.ts` → `/book/:id`

### 制約

- **新しい動的パラメータを追加する場合、必ず`_`プレフィックスを使用**

## 型安全性の実現

### 環境変数の型安全性

- [`src/type.d.ts`](src/type.d.ts:10)で`fastify.config`の型を定義
- [`src/plugins/01.env.plugin.ts`](src/plugins/01.env.plugin.ts:1)で`@fastify/env`を使用してランタイムバリデーション
- **両方のファイルを更新することで、型安全性とランタイム安全性を確保**

### データベースの型安全性

- [`src/type.d.ts`](src/type.d.ts:6)で`fastify.db`の型を定義
- drizzle-ormを使用して型安全なクエリを実現

## テストアーキテクチャ

### Testcontainersパターン

- [`tests/global-setup.ts`](tests/global-setup.ts:1)で`@testcontainers/postgresql`を使用
- **目的**：実際のPostgreSQLコンテナを使用して、本番環境に近い環境でテスト

### Fastifyインスタンスの管理

- [`tests/helpers/fastify.helper.ts`](tests/helpers/fastify.helper.ts:10)の`setupFastify()`でテストごとに独立したインスタンスを管理
- **目的**：テスト間の独立性を確保し、副作用を防ぐ

## ビルドとデプロイ

### パスエイリアスの変換

- `npm run build`は`tsc`と`tsc-alias`の両方を実行（[`package.json`](package.json:8)）
- **`tsc-alias`は必須**：Node.jsはパスエイリアスをネイティブサポートしていないため、`@/*`を実際の相対パスに変換

### 制約

- **ビルド時に`tsc-alias`を実行しないと、本番環境でモジュールが見つからないエラーが発生**
