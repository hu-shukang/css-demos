# AGENTS.md (Debug Mode)

デバッグ時の非自明な情報

## ロギングシステム

### AsyncLocalStorage (ALS) パターン

- [`src/utils/als.util.ts`](src/utils/als.util.ts:1)でリクエストスコープのロガーを管理
- [`src/hooks/01.request.hook.ts`](src/hooks/01.request.hook.ts:1)で`ALS.asyncStore.run()`を使用してロガーを初期化
- ロガーが取得できない場合は`console`にフォールバック（[`src/utils/als.util.ts`](src/utils/als.util.ts:13)）

### ログ出力の確認場所

- **リクエスト開始**：[`src/hooks/01.request.hook.ts`](src/hooks/01.request.hook.ts:11) - `Request received`
- **レスポンス情報**：[`src/hooks/99.response.hook.ts`](src/hooks/99.response.hook.ts:28) - `Response info`
- **エラー**：[`src/plugins/99.error-handler.plugin.ts`](src/plugins/99.error-handler.plugin.ts:19)

### ログレベル設定

- 環境変数`LOG_LEVEL`で制御（`trace`, `debug`, `info`, `warn`, `error`, `fatal`）
- デフォルト：`info`（[`src/plugins/01.env.plugin.ts`](src/plugins/01.env.plugin.ts:16)）

## プラグイン/フックの読み込み順序

デバッグ時は読み込み順序を確認：

1. **01.env.plugin.ts** - 環境変数の読み込み
2. **02.cors.plugin.ts** - CORS設定
3. **03.swagger.plugin.ts** - Swagger設定
4. **04.db.plugin.ts** - DB接続
5. **99.error-handler.plugin.ts** - エラーハンドラー（最後）

フック：

1. **01.request.hook.ts** - リクエスト初期化、ALSセットアップ
2. **99.response.hook.ts** - レスポンス処理、共通ヘッダー設定

## エラーハンドリング

### Zodバリデーションエラー

- [`src/plugins/99.error-handler.plugin.ts`](src/plugins/99.error-handler.plugin.ts:9)で`hasZodFastifySchemaValidationErrors()`を使用
- 400レスポンスで詳細なバリデーションエラーを返す

### カスタムエラー

- [`src/models/error.model.ts`](src/models/error.model.ts:1)で`@fastify/error`を使用して定義

## テスト環境のデバッグ

- [`tests/global-setup.ts`](tests/global-setup.ts:1)で`@testcontainers/postgresql`を使用
- PostgreSQLコンテナが起動しない場合、Dockerが実行中か確認
- テストごとに独立したFastifyインスタンスを作成（[`tests/helpers/fastify.helper.ts`](tests/helpers/fastify.helper.ts:10)）

## 環境変数の確認

- 開発環境：`env/.env`から読み込み（[`package.json`](package.json:7)の`npm run dev`）
- テスト環境：[`tests/global-setup.ts`](tests/global-setup.ts:9)で`dotenv.config()`を使用
