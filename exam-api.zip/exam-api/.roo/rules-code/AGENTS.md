# AGENTS.md (Code Mode)

コーディング時の非自明なルールと規約

## ファイル命名規則

### プラグインとフック

- **数字プレフィックス（01-99）で読み込み順序を制御**
- プラグイン：`01.env.plugin.ts`（最初）→ `99.error-handler.plugin.ts`（最後）
- フック：`01.request.hook.ts`（最初）→ `99.response.hook.ts`（最後）
- **新しいプラグイン/フックには必ず`.plugin.ts`または`.hook.ts`サフィックスを付ける**（[`src/app.ts`](src/app.ts:34)の`matchFilter`で使用）

### ルーティング

- 動的パラメータには`_`プレフィックスを使用（例：`_id`ディレクトリ → `:id`パラメータ）
- [`src/routes/book/_id/get.ts`](src/routes/book/_id/get.ts:1) → `/book/:id`

## Zodスキーマの管理

- **全てのZodスキーマ定義は[`src/utils/const.util.ts`](src/utils/const.util.ts:1)の`SCHEMA.z`に集約**
- モデルファイル（[`src/models/`](src/models/)）では`SCHEMA.z`から再利用
- 新しいフィールドを追加する場合：
  1. `SCHEMA.z`に定義を追加
  2. モデルファイルで`SCHEMA.z.xxx`を参照

## ロガーの使用方法

- **ビジネスロジック**：[`src/utils/logger.util.ts`](src/utils/logger.util.ts:1)から`logger`をインポート
- **フック内**：`request.log`を使用
- AsyncLocalStorage（[`src/utils/als.util.ts`](src/utils/als.util.ts:1)）でリクエストスコープのロガーを管理

## 環境変数の追加

新しい環境変数を追加する場合、以下の2ファイルを更新：

1. [`src/type.d.ts`](src/type.d.ts:10) - `fastify.config`の型定義
2. [`src/plugins/01.env.plugin.ts`](src/plugins/01.env.plugin.ts:1) - バリデーションスキーマ

## ビルド

- `npm run build`は`tsc`と`tsc-alias`の両方を実行
- **`tsc-alias`は`@/*`パスエイリアスを実際のパスに変換するために必須**

## インポート順序

[`prettier.config.mjs`](prettier.config.mjs:12)で自動整形：

1. `tsconfig-paths/register`
2. サードパーティモジュール
3. `@/*`（プロジェクト内部）
4. 相対パス

## ESLint特殊ルール

- `**/*swagger.plugin.ts`は除外（型エラーを無視）
- 未使用変数は`_`プレフィックスで無視（例：`_request`, `_reply`）
