# AGENTS.md (Ask Mode)

ドキュメント理解のための非自明な情報

## プロジェクトアーキテクチャ

### プラグインシステム

- **数字プレフィックス（01-99）で読み込み順序を制御**
- [`src/app.ts`](src/app.ts:32)で`@fastify/autoload`を使用
- `matchFilter: (path) => path.includes('plugin')`で`.plugin.ts`ファイルのみを読み込み

### フックシステム

- [`src/app.ts`](src/app.ts:37)で`@fastify/autoload`を使用
- `matchFilter: (path) => path.includes('hook')`で`.hook.ts`ファイルのみを読み込み

### ルーティングシステム

- [`src/app.ts`](src/app.ts:42)で`dirNameRoutePrefix: true`を使用
- ディレクトリ名がルートプレフィックスになる
- `_`プレフィックスのディレクトリは動的パラメータに変換（例：`_id` → `:id`）

## AsyncLocalStorage (ALS) パターン

- [`src/utils/als.util.ts`](src/utils/als.util.ts:1)でリクエストスコープのコンテキストを管理
- [`src/hooks/01.request.hook.ts`](src/hooks/01.request.hook.ts:13)で`ALS.asyncStore.run()`を使用してロガーを初期化
- [`src/utils/logger.util.ts`](src/utils/logger.util.ts:1)はALSからロガーを取得するプロキシ
- **目的**：リクエストごとに独立したロガーインスタンスを提供し、ログにリクエストIDを自動的に含める

## Zodスキーマの設計思想

- [`src/utils/const.util.ts`](src/utils/const.util.ts:1)の`SCHEMA.z`に全てのZodスキーマ定義を集約
- **目的**：
  - スキーマの再利用性を高める
  - バリデーションルールの一元管理
  - エラーメッセージの統一
- モデルファイル（[`src/models/`](src/models/)）では`SCHEMA.z`から参照してスキーマを構築

## 型安全性の実現

### 環境変数

- [`src/type.d.ts`](src/type.d.ts:10)で`fastify.config`の型を定義
- [`src/plugins/01.env.plugin.ts`](src/plugins/01.env.plugin.ts:1)で`@fastify/env`を使用してランタイムバリデーション
- **両方のファイルを更新することで、型安全性とランタイム安全性を確保**

### データベース

- [`src/type.d.ts`](src/type.d.ts:6)で`fastify.db`の型を定義
- [`src/plugins/04.db.plugin.ts`](src/plugins/04.db.plugin.ts:11)で`fastify.decorate('db', db)`を使用

## テストアーキテクチャ

- [`tests/global-setup.ts`](tests/global-setup.ts:1)で`@testcontainers/postgresql`を使用してPostgreSQLコンテナを起動
- [`tests/helpers/fastify.helper.ts`](tests/helpers/fastify.helper.ts:10)の`setupFastify()`でテストごとに独立したFastifyインスタンスを管理
- **目的**：テスト間の独立性を確保し、副作用を防ぐ

## ビルドプロセス

- `npm run build`は`tsc`と`tsc-alias`の両方を実行（[`package.json`](package.json:8)）
- **`tsc-alias`の役割**：`@/*`パスエイリアスを実際の相対パスに変換（Node.jsはパスエイリアスをネイティブサポートしていないため）
